#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python run.py doctor
python -m unittest tests.test_00_core -v
python -m unittest tests.test_10_cli_and_schemas.TestCLI -v
python -m unittest tests.test_10_cli_and_schemas.TestSchemas -v
python scripts/validate_schemas.py
rm -rf outputs/apeiron_demo
python run.py demo --out outputs/apeiron_demo
python run.py verify outputs/apeiron_demo
