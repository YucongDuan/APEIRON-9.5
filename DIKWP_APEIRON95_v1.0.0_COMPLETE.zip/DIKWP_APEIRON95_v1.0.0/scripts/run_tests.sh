#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"
python -m unittest tests.test_00_core -v
python -m unittest tests.test_10_cli_and_schemas.TestCLI -v
python -m unittest tests.test_10_cli_and_schemas.TestSchemas -v
