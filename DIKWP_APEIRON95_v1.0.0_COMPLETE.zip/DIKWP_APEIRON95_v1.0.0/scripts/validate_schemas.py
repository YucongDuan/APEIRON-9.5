from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

try:
    from jsonschema import Draft202012Validator
except ImportError:
    Draft202012Validator = None


def _load(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    schema_dir = ROOT / "schemas"
    schemas = {p.name: _load(p) for p in sorted(schema_dir.glob("*.json"))}
    for name, schema in schemas.items():
        if schema.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
            raise SystemExit(f"{name}: unexpected schema dialect")
        if Draft202012Validator:
            Draft202012Validator.check_schema(schema)

    demo = ROOT / "outputs" / "apeiron_demo"
    if demo.is_dir() and Draft202012Validator:
        pairs = [
            (schemas["event-stream.schema.json"], _load(ROOT / "examples" / "cosmic_sensor_stream.json")),
            (schemas["apeiron-bundle.schema.json"], _load(demo / "apeiron_bundle.json")),
            (schemas["machine-concept.schema.json"], _load(demo / "machine_native_concepts.json")["concepts"][0]),
            (schemas["transcomprehension-certificate.schema.json"], _load(demo / "transcomprehension_certificates.json")["projection_certificates"][0]),
            (schemas["cosmic-handshake.schema.json"], _load(demo / "cosmic_handshake_protocol.json")),
        ]
        for schema, instance in pairs:
            Draft202012Validator(schema).validate(instance)

    print(json.dumps({
        "valid": True,
        "schema_count": len(schemas),
        "instances_validated": 5 if demo.is_dir() and Draft202012Validator else 0,
        "validator": "jsonschema" if Draft202012Validator else "syntax-only",
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
