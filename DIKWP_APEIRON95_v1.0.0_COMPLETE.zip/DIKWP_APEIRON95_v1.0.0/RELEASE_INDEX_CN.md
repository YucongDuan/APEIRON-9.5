# DIKWP-APEIRON 9.5 发布索引

## 推荐入口

- `README_CN.md`：中文总览与运行说明。
- `outputs/apeiron_demo/COSMIC_SYSTEM_REPORT_CN.md`：完整中文系统报告。
- `outputs/apeiron_demo/dashboard.html`：完全离线仪表盘。
- `outputs/apeiron_demo/apeiron_core.apx`：APX95非语言核心。
- `outputs/apeiron_demo/apeiron_bundle.json`：完整机器可读系统包。
- `docs/FORMAL_SPEC_CN_EN.md`：形式规范。
- `docs/NONLINGUISTIC_CORE_CN_EN.md`：非语言核心说明。
- `docs/TRANSCOMPREHENSION_CERTIFICATES_CN_EN.md`：超理解间隙证书。
- `docs/RELIGION_CIVILIZATION_BRIDGE_CN.md`：宗教文明与DIKWP边界桥。
- `docs/CLAIM_BOUNDARIES_CN_EN.md`：主张边界。
- `docs/VALIDATION_CN_EN.md`：验证范围。
- `RELEASE_VALIDATION.json`：最终机器可读验证回执。

## 运行

```bash
python run.py doctor
python run.py demo --out outputs/apeiron_demo
python run.py verify outputs/apeiron_demo
```

## 测试

```bash
./scripts/run_tests.sh
python scripts/validate_schemas.py
```

## 权限边界

自动外部行动权限、自动自我修改权限与宇宙握手发射权限均为零。
