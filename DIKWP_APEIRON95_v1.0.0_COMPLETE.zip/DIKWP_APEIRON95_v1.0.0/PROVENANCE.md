# Provenance

DIKWP-APEIRON 9.5 is a successor system to EIDOS95, NOESIS95 and COSMONOESIS95. It incorporates the user-supplied Mesh95 default mode and imports a compact, digest-bound COSMONOESIS95 seed for the religious-civilizational boundary layer.

Research references are stored in `src/dikwp_apeiron95/data/research_basis.json`. They are design inspirations and comparison points, not evidence that the combined system is a proven theory of the universe.

The bundled event stream is synthetic and deterministic. Its output is a software demonstration, not an astronomical observation.
