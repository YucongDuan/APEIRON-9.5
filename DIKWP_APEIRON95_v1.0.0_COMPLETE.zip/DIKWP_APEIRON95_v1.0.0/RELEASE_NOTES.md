# DIKWP-APEIRON 9.5 v1.0.0 Release Notes

This first release replaces language-centred semantic normalization as the canonical core with a deterministic event-and-structure substrate. Human language and DIKWP remain indispensable at the interface of interpretation, values, rights, purpose and action, but no longer define machine-native identity.

The release includes a source package, wheel, complete offline package, synthetic demonstration, APX95 binary core, HTML dashboard, formal specifications, schemas, tests and SHA-256 manifests.

Release validation covers 118 deterministic tests, JSON Schema validation, clean source-archive execution, clean complete-archive execution, isolated wheel installation, APX95 round-trip checks, label/action/environment renaming invariance and manifest tamper detection. These are software and local-method validation results, not a certificate of final cosmological truth.
