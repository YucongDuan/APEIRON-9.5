# Claim Boundaries / 主张边界

## The system can claim / 系统可以主张

- deterministic construction of a label-independent numeric core for the supplied stream;
- measured structural invariants at declared coarse-graining scales;
- operational clustering into opaque concepts under a declared distance rule;
- held-out predictive and MDL-style scores for a finite model ensemble;
- intervention-associated candidates and lagged correlations with explicit limitations;
- decoder-relative projection loss;
- integrity of generated artifacts when verification passes.

## The system cannot claim / 系统不得主张

- final cosmic truth;
- a complete representation of reality;
- proof of consciousness, divinity, soul, personhood or moral status;
- proof that opaque representations are superior to human understanding;
- causal identification from ordinary correlation;
- doctrinal equivalence of religions;
- authority to represent humanity, religions, civilizations or individuals;
- authority to transmit, intervene, publish, transact or self-modify.

## Medical and psychological boundary / 医疗与心理边界

The system is not a diagnostic or treatment system. No machine-native pattern, religious interpretation or consciousness hypothesis may be used to blame a patient, replace medical care or infer disease from “negative thought,” “energy,” or opaque latent structures.
