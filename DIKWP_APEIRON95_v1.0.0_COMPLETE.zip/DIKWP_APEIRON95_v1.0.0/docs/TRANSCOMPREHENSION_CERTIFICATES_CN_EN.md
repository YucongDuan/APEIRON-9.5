# Transcomprehension Certificates / 超理解间隙证书

A transcomprehension certificate is deliberately weaker than the phrase “beyond human understanding.” It states that a specified human-readable decoder under a specified budget loses measurable predictive distinctions that remain available in the machine-native representation.

## Required fields

- full representation identifier;
- decoder family;
- representation budget;
- held-out full loss;
- held-out projected loss;
- additional loss;
- predictive fidelity;
- witness transitions;
- scope and expiry conditions;
- explicit `human_comprehension_impossibility_claim=false`.

## Invalid uses

A certificate must not be used to claim:

- the opaque structure is metaphysically true;
- humans can never understand it;
- an AI deserves authority because it is opaque;
- a person or community should defer to the system;
- loss of interpretability justifies unreviewable external action.

## Decoder evolution

When a gap is found, the preferred response is not forced obedience. The system proposes new decoders: relation-first visualizations, counterexample-first explanations, interactive interventions, multi-scale diagrams or formal proof witnesses. Original opaque identifiers remain stable so improved explanations do not rewrite history.
