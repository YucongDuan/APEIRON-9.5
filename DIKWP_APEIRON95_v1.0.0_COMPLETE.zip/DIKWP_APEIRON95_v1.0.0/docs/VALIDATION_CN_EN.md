# Validation / 验证说明

## Test inventory / 测试清单

The release contains 118 deterministic tests:

- 99 core, mathematical, invariance, model, governance, compilation and tamper-detection tests;
- 10 command-line integration tests;
- 9 JSON Schema and schema-runner tests.

发布版包含118项确定性测试：99项核心与治理测试、10项命令行集成测试、9项Schema测试。

## What is validated / 已验证内容

- labels, action names and environment names do not alter the structural core when occurrence structure is preserved;
- APX95 artifacts round-trip and reject invalid headers;
- multiple scales and eight non-isomorphic model families remain present;
- machine-native concepts have no required human name;
- causal outputs remain candidates, never certificates;
- transcomprehension outputs remain decoder-relative;
- all governed entities receive DIKWP envelopes with zero outside residual;
- manifest tampering is detected;
- external-action and self-modification authority remain zero;
- source, complete-package and installed-wheel execution are reproduced during release validation.

## What is not validated / 未验证内容

The tests do not prove a final cosmology, universal consciousness, metaphysical truth, permanent human incomprehensibility, extraterrestrial agency, or the physical reality of a discovered concept. They validate software contracts and falsifiable local properties only.
