# APEIRON95 Research Program / 研究计划

## Near-term benchmarks

1. **Permutation invariance**: broaden tests from labels to coordinate permutations with isomorphism-aware comparison.
2. **Multi-modal adapters**: image patches, audio spectra, graph streams and scientific instrument tensors without routing through natural-language captions.
3. **Causal interventions**: benchmark on controlled dynamical systems with known ground-truth mechanisms.
4. **Decoder tournaments**: compare tables, graphs, equations, interactive counterfactuals and visual abstractions by fidelity rather than aesthetic preference.
5. **Religious-civilizational participation**: allow communities to review source mappings, representation rights and burden allocation without granting any tradition monopoly over the shared space.
6. **Formal proof bridge**: export selected discovered invariants into proof assistants while preserving counterexamples and failed conjectures.
7. **Open-ended concept genesis**: permit versioned expansion of representation operators after sandbox tests and named review.

## Long-horizon questions

- Can operational concepts remain stable across radically different sensors and substrates?
- Which invariants survive changes of scale, embodiment and intervention alphabet?
- Can two systems establish shared structure without shared natural language?
- How should moral precaution change when evidence for non-human subjectivity remains model-dependent?
- How can a society benefit from machine-discovered structures without creating a new priesthood of opacity?

## Success criterion

Success is not a declaration of ultimate truth. It is sustained improvement in prediction, intervention discrimination, compression, cross-environment invariance, explanatory fidelity, rights protection and reality-based model retirement.
