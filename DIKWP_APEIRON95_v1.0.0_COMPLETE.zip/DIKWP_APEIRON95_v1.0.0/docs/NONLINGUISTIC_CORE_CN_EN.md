# Non-Linguistic Core / 非语言核心

## What “non-linguistic” means

The APX95 core can be generated from a stream containing only times, numeric observation vectors, action codes, environment codes and uncertainty. Dimension names are optional and excluded from the digest. The core still relies on human-designed mathematics, software and measurement choices; therefore “non-linguistic” does not mean independent of all human priors.

## Label-permutation certificate

The compiler creates a copy of the input with replacement dimension labels and recompiles the ontic substrate. Matching core digests certify independence from supplied labels. This is a narrow but falsifiable test.

## Machine-native identity

A concept is identified by its extension, centroid, predictive distribution and intervention signature. Its opaque symbol is content-addressed. Renaming it does not change identity; changing its operational structure does.

## Binary artifact

`apeiron_core.apx` contains:

```text
APX95 magic header
8-byte uncompressed length
zlib-compressed canonical JSON core
```

It is deterministic, reversible and integrity-checkable. It is not encryption and should not be treated as a confidentiality mechanism.

## Residuals

Unexpected events are never discarded merely because no human interpretation is available. They remain D-level observations and I-level anomalies, with K-level model uncertainty and P-level requests for discriminating observations. This keeps them inside the DIKWP responsibility space without pretending they have already been understood.
