# DIKWP-APEIRON 9.5 Formal Specification / 形式规范

## A. Core object

```math
Ξ_t = (E_t, Q_t, A_t, G_t, R_t, M_t, C_t)
```

- `E_t`: append-only event worldline;
- `Q_t`: numerical observation coordinates;
- `A_t`: intervention alphabet after first-occurrence canonicalization;
- `G_t`: environment alphabet;
- `R_t`: relation and transition structures;
- `M_t`: plural world-model ensemble;
- `C_t`: machine-native concepts.

Human names are metadata, not members of the canonical tuple.

## B. Predictive equivalence

```math
x ~_ε y iff d(P(F|do(A),x), P(F|do(A),y)) <= ε
```

This defines operational concepts. It does not prove that the concept corresponds to a fundamental entity in nature.

## C. Scale selection

Each scale receives a pragmatic score:

```math
S_s = 1/(1+L_holdout)
    + .20 * predictive_efficiency
    + .10 * action_efficiency
    + .08 * persistence
    - .25 * singleton_fraction
```

All scales remain in the atlas even when one is selected for downstream computation.

## D. Model comparison

```math
MDL(M) = test_description_length(M) + complexity_proxy(M)
```

The proxy is intentionally simple and reproducible. It is not a universal Kolmogorov-complexity oracle.

## E. Transcomprehension certificate

Given a decoder `π_B` with budget `B`:

```math
Gap_B = L(π_B(C)) - L(C)
Fidelity_B = exp(-max(0, Gap_B))
```

A gap is recorded only when the budget is lower than the full concept count, additional loss exceeds the configured margin, and fidelity drops below the threshold. The certificate scope includes the decoder, budget, stream and witness transitions.

## F. DIKWP bridge

```math
Φ: entity → (v_32, v_DIKWP, loss, authority)
```

Subject to:

```text
sum(v_32)=1
outside_residual=0
core_replaced=false
automatic_external_action_authority=0
```

## G. Ultimate-open criterion

```math
U* = sup [prediction + intervention discrimination + compression + invariance
          - complexity - harm - hidden burden]
```

subject to provenance, reversibility, plurality, result return, model retirement and successor freedom. `U*` is a design objective, not a claim that the supremum has been reached.
