# Governance

APEIRON95 follows the Mesh95 stance `FACTUALLY_OBJECTIVE_RELATIONALLY_PROTECTIVE`.

- High-impact conclusions preserve multiple non-isomorphic models.
- Projection loss, opacity and uncertainty must be visible to affected people.
- Politeness, participation, public data or silence do not imply consent, endorsement or identity-use authorization.
- Higher-leverage operators carry a higher duty to disclose scope, avoid burden transfer, preserve credit and enable refusal.
- Religious, civilizational and indigenous materials do not become ownerless because they can be normalized computationally.
- Every external action requires named, scoped and revocable authorization.
- Automatic external action and automatic self-modification authority remain zero.
