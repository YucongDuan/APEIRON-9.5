# Changelog

## 1.0.0 — 2026-08-31

- Added APX95 non-linguistic event core.
- Added multi-scale invariant atlas and label-permutation certificate.
- Added opaque machine-native concept discovery.
- Added eight-family world-model ensemble and MDL-style comparison.
- Added intervention-associated causal candidates.
- Added decoder-relative transcomprehension certificates.
- Added DIKWP non-reductive responsibility bridge and COSMONOESIS95 import.
- Added offline structural cosmic handshake.
- Added reversible metamorphosis proposals, tests and release verification.
