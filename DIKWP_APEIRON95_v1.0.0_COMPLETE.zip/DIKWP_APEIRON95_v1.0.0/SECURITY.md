# Security

APEIRON95 is designed for offline analysis. The core package performs no network requests and holds no credentials. The cosmic handshake command generates a local candidate packet only; it does not transmit.

Do not use this software to control critical infrastructure, medical treatment, weapons, surveillance, coercive profiling or autonomous contact attempts. Treat APX files as integrity artifacts, not encryption. Review input provenance and remove sensitive data before sharing compiled outputs.

Report vulnerabilities with a minimal reproducible example. Do not include personal, religious or cultural data without authorization.
