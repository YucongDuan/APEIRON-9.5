# Contributing

Contributions should preserve deterministic builds, source provenance, label-independent core tests, DIKWP boundary closure, model plurality, named authorization and zero automatic external-action authority.

Every new model family must state its assumptions, distinguishing evidence, failure conditions and retirement criteria. Every new decoder must report projection fidelity and must not silently rewrite opaque concept identities.
