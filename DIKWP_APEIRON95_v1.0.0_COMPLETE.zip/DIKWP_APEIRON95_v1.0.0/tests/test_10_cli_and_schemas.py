from __future__ import annotations

import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PYTHON = sys.executable


def run_cli(*args: str, expect: int = 0) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(
        [PYTHON, "run.py", *args], cwd=ROOT, text=True, capture_output=True,
        timeout=120,
    )
    if result.returncode != expect:
        raise AssertionError(f"return={result.returncode}\nstdout={result.stdout}\nstderr={result.stderr}")
    return result


class TestCLI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls._tmp = tempfile.TemporaryDirectory()
        cls.compiled_demo = Path(cls._tmp.name) / "compiled-demo"
        run_cli("compile", "--stream", "examples/tiny_event_stream.json", "--out", str(cls.compiled_demo))

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    def test_doctor(self):
        data = json.loads(run_cli("doctor").stdout)
        self.assertTrue(data["valid"])
        self.assertEqual(data["automatic_external_action_authority"], 0)

    def test_analyze(self):
        data = json.loads(run_cli("analyze", "--stream", "examples/tiny_event_stream.json").stdout)
        self.assertEqual(data["event_count"], 72)
        self.assertTrue(data["label_invariance_passed"])

    def test_concepts(self):
        data = json.loads(run_cli("concepts", "--stream", "examples/tiny_event_stream.json").stdout)
        self.assertGreater(data["concept_count"], 0)

    def test_models(self):
        data = json.loads(run_cli("models", "--stream", "examples/tiny_event_stream.json").stdout)
        self.assertEqual(data["model_count"], 8)

    def test_opacity(self):
        data = json.loads(run_cli("opacity", "--stream", "examples/tiny_event_stream.json", "--budgets", "2", "4").stdout)
        self.assertEqual([x["budget"] for x in data["projection_certificates"]], [2, 4])

    def test_handshake(self):
        data = json.loads(run_cli("handshake", "--stream", "examples/tiny_event_stream.json").stdout)
        self.assertFalse(data["transmission_authorized"])

    def test_compile_and_verify(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "cli-output"
            compiled = json.loads(run_cli("compile", "--stream", "examples/tiny_event_stream.json", "--out", str(out)).stdout)
            self.assertTrue(compiled["compiled"])
            verified = json.loads(run_cli("verify", str(out)).stdout)
            self.assertTrue(verified["valid"])

    def test_decode_core(self):
        data = json.loads(run_cli("decode-core", str(self.compiled_demo / "apeiron_core.apx")).stdout)
        self.assertEqual(data["format"], "APX95_NONLINGUISTIC_CORE_1.0")
        self.assertFalse(data["human_labels_in_core"])

    def test_invalid_stream_returns_two(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "bad.json"
            path.write_text('{"events": []}', encoding="utf-8")
            result = run_cli("analyze", "--stream", str(path), expect=2)
            self.assertIn("error", json.loads(result.stdout))

    def test_help(self):
        result = subprocess.run([PYTHON, "run.py", "--help"], cwd=ROOT, text=True, capture_output=True, timeout=30)
        self.assertEqual(result.returncode, 0)
        self.assertIn("apeiron95", result.stdout)


class TestSchemas(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            from jsonschema import Draft202012Validator
        except ImportError:
            raise unittest.SkipTest("jsonschema unavailable")
        cls.validator = Draft202012Validator
        cls.schemas = {p.name: json.loads(p.read_text(encoding="utf-8")) for p in (ROOT / "schemas").glob("*.json")}
        cls._tmp = tempfile.TemporaryDirectory()
        cls.demo = Path(cls._tmp.name) / "schema-demo"
        run_cli("compile", "--stream", "examples/tiny_event_stream.json", "--out", str(cls.demo))

    @classmethod
    def tearDownClass(cls):
        cls._tmp.cleanup()

    def test_schema_count(self):
        self.assertEqual(len(self.schemas), 5)

    def test_schema_dialect(self):
        for schema in self.schemas.values():
            self.assertEqual(schema["$schema"], "https://json-schema.org/draft/2020-12/schema")

    def test_schema_definitions_valid(self):
        for schema in self.schemas.values():
            self.validator.check_schema(schema)

    def test_event_stream_validates(self):
        instance = json.loads((ROOT / "examples" / "cosmic_sensor_stream.json").read_text(encoding="utf-8"))
        self.validator(self.schemas["event-stream.schema.json"]).validate(instance)

    def test_bundle_validates(self):
        instance = json.loads((self.demo / "apeiron_bundle.json").read_text(encoding="utf-8"))
        self.validator(self.schemas["apeiron-bundle.schema.json"]).validate(instance)

    def test_machine_concept_validates(self):
        instance = json.loads((self.demo / "machine_native_concepts.json").read_text(encoding="utf-8"))["concepts"][0]
        self.validator(self.schemas["machine-concept.schema.json"]).validate(instance)

    def test_transcomprehension_certificate_validates(self):
        instance = json.loads((self.demo / "transcomprehension_certificates.json").read_text(encoding="utf-8"))["projection_certificates"][0]
        self.validator(self.schemas["transcomprehension-certificate.schema.json"]).validate(instance)

    def test_handshake_validates(self):
        instance = json.loads((self.demo / "cosmic_handshake_protocol.json").read_text(encoding="utf-8"))
        self.validator(self.schemas["cosmic-handshake.schema.json"]).validate(instance)

    def test_validation_script(self):
        result = subprocess.run([PYTHON, "scripts/validate_schemas.py"], cwd=ROOT, text=True, capture_output=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue(json.loads(result.stdout)["valid"])


if __name__ == "__main__":
    unittest.main()
