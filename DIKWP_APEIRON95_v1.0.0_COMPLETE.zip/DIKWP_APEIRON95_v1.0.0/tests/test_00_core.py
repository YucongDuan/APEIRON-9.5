from __future__ import annotations

import copy
import json
import math
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from dikwp_apeiron95.bridge import build_dikwp_bridge, import_cosmonoesis_bridge
from dikwp_apeiron95.causal import discover_causal_hypotheses
from dikwp_apeiron95.compiler import MESH_MODE, SYSTEM_NAME, VERSION, compile_system
from dikwp_apeiron95.concepts import discover_concepts
from dikwp_apeiron95.handshake import build_cosmic_handshake
from dikwp_apeiron95.invariants import analyze_scale, cross_scale_persistence, normalized_mutual_information, state_sequence
from dikwp_apeiron95.metamorphosis import propose_metamorphoses
from dikwp_apeiron95.multiscale import analyze_multiscale, selected_scale
from dikwp_apeiron95.opacity import build_transcomprehension_certificates
from dikwp_apeiron95.render import render_dashboard, render_report
from dikwp_apeiron95.substrate import build_substrate, core_digest_for_stream, relabel_stream
from dikwp_apeiron95.utils import (
    APX_MAGIC, canonical_json, clamp, conditional_entropy, cosine_dense, decode_apx,
    encode_apx, entropy_from_counts, entropy_of, euclidean, js_divergence, log_loss_bits,
    manifest_for, mean, normalize_distribution, normalize_text, pearson, quantize,
    round_floats, sha256_bytes, sha256_obj, stable_id, stddev, variance,
)
from dikwp_apeiron95.verify import verify_output_dir
from dikwp_apeiron95.worldmodels import fit_world_model_ensemble


def demo_stream() -> dict:
    return json.loads((ROOT / "examples" / "cosmic_sensor_stream.json").read_text(encoding="utf-8"))


class TestUtils(unittest.TestCase):
    def test_canonical_json_sorts_keys(self):
        self.assertEqual(canonical_json({"b": 1, "a": 2}), '{"a":2,"b":1}')

    def test_sha256_bytes_length(self):
        self.assertEqual(len(sha256_bytes(b"x")), 64)

    def test_sha256_obj_is_deterministic(self):
        self.assertEqual(sha256_obj({"x": [1, 2]}), sha256_obj({"x": [1, 2]}))

    def test_stable_id_prefix_and_length(self):
        value = stable_id("test", {"x": 1}, length=12)
        self.assertTrue(value.startswith("test-"))
        self.assertEqual(len(value.split("-", 1)[1]), 12)

    def test_normalize_text(self):
        self.assertEqual(normalize_text("  A\t B\n\n\nC  "), "A B\n\nC")

    def test_clamp(self):
        self.assertEqual(clamp(-2), 0.0)
        self.assertEqual(clamp(2), 1.0)
        self.assertEqual(clamp("bad"), 0.0)

    def test_mean_empty(self):
        self.assertEqual(mean([]), 0.0)

    def test_variance_and_stddev(self):
        self.assertAlmostEqual(variance([1, 2, 3]), 2 / 3)
        self.assertAlmostEqual(stddev([1, 2, 3]), math.sqrt(2 / 3))

    def test_entropy_counts(self):
        self.assertAlmostEqual(entropy_from_counts([1, 1]), 1.0)
        self.assertEqual(entropy_from_counts([]), 0.0)

    def test_entropy_of(self):
        self.assertAlmostEqual(entropy_of(["a", "b"]), 1.0)

    def test_conditional_entropy_deterministic(self):
        self.assertEqual(conditional_entropy([("a", 1), ("b", 2)]), 0.0)

    def test_normalize_distribution(self):
        dist = normalize_distribution({"a": 1, "b": 1})
        self.assertAlmostEqual(sum(dist.values()), 1.0)
        self.assertAlmostEqual(dist["a"], 0.5)

    def test_normalize_distribution_zero_weights(self):
        dist = normalize_distribution({"a": 0, "b": 0})
        self.assertAlmostEqual(dist["a"], 0.5)

    def test_js_divergence_identity(self):
        self.assertAlmostEqual(js_divergence({"a": 1}, {"a": 1}), 0.0)

    def test_js_divergence_symmetry(self):
        a = {"a": 0.9, "b": 0.1}
        b = {"a": 0.1, "b": 0.9}
        self.assertAlmostEqual(js_divergence(a, b), js_divergence(b, a))

    def test_cosine_dense(self):
        self.assertAlmostEqual(cosine_dense([1, 0], [1, 0]), 1.0)
        self.assertEqual(cosine_dense([0, 0], [1, 0]), 0.0)

    def test_vector_length_errors(self):
        with self.assertRaises(ValueError):
            cosine_dense([1], [1, 2])
        with self.assertRaises(ValueError):
            euclidean([1], [1, 2])

    def test_euclidean(self):
        self.assertAlmostEqual(euclidean([0, 0], [3, 4]), 5.0)

    def test_pearson(self):
        self.assertAlmostEqual(pearson([1, 2, 3], [2, 4, 6]), 1.0)
        self.assertEqual(pearson([1], [1]), 0.0)

    def test_quantize(self):
        self.assertEqual(quantize(0.0, 4), 0)
        self.assertEqual(quantize(1.0, 4), 3)
        with self.assertRaises(ValueError):
            quantize(0.2, 1)

    def test_log_loss_bits(self):
        self.assertAlmostEqual(log_loss_bits(1.0), 0.0)
        self.assertGreater(log_loss_bits(0.5), 0.0)

    def test_round_floats_recursive(self):
        self.assertEqual(round_floats({"x": [1.23456]}, 2), {"x": [1.23]})

    def test_apx_roundtrip(self):
        obj = {"x": [1, 2], "unicode": "宇宙"}
        encoded = encode_apx(obj)
        self.assertTrue(encoded.startswith(APX_MAGIC))
        self.assertEqual(decode_apx(encoded), obj)

    def test_apx_invalid_magic(self):
        with self.assertRaises(ValueError):
            decode_apx(b"not-apx")

    def test_apx_truncated(self):
        with self.assertRaises(ValueError):
            decode_apx(APX_MAGIC)


class PipelineFixture(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.raw = demo_stream()
        cls.substrate = build_substrate(cls.raw)
        cls.atlas = analyze_multiscale(cls.substrate)
        cls.scale = selected_scale(cls.atlas)
        cls.concepts = discover_concepts(cls.substrate, cls.scale)
        cls.models = fit_world_model_ensemble(cls.substrate, cls.scale, cls.concepts, cls.atlas)
        cls.causal = discover_causal_hypotheses(cls.substrate)
        cls.opacity = build_transcomprehension_certificates(cls.raw, cls.substrate, cls.concepts)
        cls.handshake = build_cosmic_handshake(cls.substrate["core_digest"], cls.scale["invariants"]["structural_fingerprint"])
        cls.meta = propose_metamorphoses(cls.atlas, cls.concepts, cls.models, cls.causal, cls.opacity)
        cls.bridge = build_dikwp_bridge(
            cls.substrate, cls.atlas, cls.concepts, cls.models, cls.causal,
            opacity=cls.opacity, handshake=cls.handshake, metamorphosis=cls.meta,
        )


class TestSubstrate(PipelineFixture):
    def test_event_count(self):
        self.assertEqual(self.substrate["statistics"]["event_count"], 360)

    def test_dimension_count(self):
        self.assertEqual(self.substrate["statistics"]["dimension_count"], 6)

    def test_labels_are_interface_only(self):
        self.assertTrue(self.substrate["interface_metadata"]["labels_excluded_from_core_digest"])
        self.assertFalse(self.substrate["language_required_for_core"])

    def test_relabel_invariance(self):
        relabeled = relabel_stream(self.raw, [f"new-{i}" for i in range(6)])
        self.assertEqual(core_digest_for_stream(self.raw), core_digest_for_stream(relabeled))

    def test_action_rename_invariance(self):
        renamed = copy.deepcopy(self.raw)
        mapping = {0: "none", 1: "pulse", 2: "counter-pulse"}
        for event in renamed["events"]:
            event["action"] = mapping[event.get("action", 0)]
        self.assertEqual(core_digest_for_stream(self.raw), core_digest_for_stream(renamed))

    def test_environment_rename_invariance(self):
        renamed = copy.deepcopy(self.raw)
        mapping = {0: "alpha", 1: "beta", 2: "gamma"}
        for event in renamed["events"]:
            event["environment"] = mapping[event.get("environment", 0)]
        self.assertEqual(core_digest_for_stream(self.raw), core_digest_for_stream(renamed))

    def test_observation_change_changes_digest(self):
        changed = copy.deepcopy(self.raw)
        changed["events"][12]["observation"][0] += 0.123
        self.assertNotEqual(core_digest_for_stream(self.raw), core_digest_for_stream(changed))

    def test_core_digest_deterministic(self):
        self.assertEqual(build_substrate(self.raw)["core_digest"], self.substrate["core_digest"])

    def test_event_ids_unique(self):
        ids = [e["event_id"] for e in self.substrate["core"]["events"]]
        self.assertEqual(len(ids), len(set(ids)))

    def test_normalized_coordinates_bounded(self):
        values = [v for e in self.substrate["core"]["events"] for v in e["observation"]]
        self.assertGreaterEqual(min(values), 0.0)
        self.assertLessEqual(max(values), 1.0)

    def test_uncertainty_bounded(self):
        values = [e["uncertainty"] for e in self.substrate["core"]["events"]]
        self.assertTrue(all(0.0 <= x <= 1.0 for x in values))

    def test_constant_coordinate_becomes_half(self):
        raw = {"events": [{"t": i, "observation": [5, i]} for i in range(4)]}
        sub = build_substrate(raw)
        self.assertTrue(all(e["observation"][0] == 0.5 for e in sub["core"]["events"]))

    def test_too_few_events_rejected(self):
        with self.assertRaises(ValueError):
            build_substrate({"events": [{"observation": [1]}]})

    def test_non_object_rejected(self):
        with self.assertRaises(ValueError):
            build_substrate([])

    def test_non_numeric_observation_rejected(self):
        with self.assertRaises(ValueError):
            build_substrate({"events": [{"t": i, "observation": ["x"]} for i in range(4)]})

    def test_non_finite_observation_rejected(self):
        raw = {"events": [{"t": i, "observation": [0.0]} for i in range(4)]}
        raw["events"][2]["observation"][0] = float("nan")
        with self.assertRaises(ValueError):
            build_substrate(raw)

    def test_dimension_mismatch_rejected(self):
        raw = {"events": [{"t": 0, "observation": [0]}, {"t": 1, "observation": [0, 1]}, {"t": 2, "observation": [0]}, {"t": 3, "observation": [0]}]}
        with self.assertRaises(ValueError):
            build_substrate(raw)

    def test_label_mismatch_rejected(self):
        raw = {"dimension_labels": ["only"], "events": [{"t": i, "observation": [i, i]} for i in range(4)]}
        with self.assertRaises(ValueError):
            build_substrate(raw)

    def test_non_increasing_time_rejected(self):
        raw = {"events": [{"t": 0, "observation": [0]}, {"t": 1, "observation": [1]}, {"t": 1, "observation": [2]}, {"t": 3, "observation": [3]}]}
        with self.assertRaises(ValueError):
            build_substrate(raw)


class TestStructureAndConcepts(PipelineFixture):
    def test_state_sequence_length(self):
        seq = state_sequence(self.substrate, 2)
        self.assertEqual(len(seq["sequence"]), 360)

    def test_state_ids_are_opaque(self):
        seq = state_sequence(self.substrate, 2)
        self.assertTrue(all(x.startswith("s2-") for x in seq["state_values"]))

    def test_analyze_scale_preserves_event_count(self):
        scale = analyze_scale(self.substrate, 3)
        self.assertEqual(scale["invariants"]["event_count"], 360)

    def test_analyze_scale_is_label_invariant(self):
        relabeled = build_substrate(relabel_stream(self.raw, ["z"] * 6))
        self.assertEqual(analyze_scale(relabeled, 3)["invariants"]["structural_fingerprint"], analyze_scale(self.substrate, 3)["invariants"]["structural_fingerprint"])

    def test_normalized_mutual_information_identity(self):
        self.assertAlmostEqual(normalized_mutual_information(["a", "b", "a"], ["a", "b", "a"]), 1.0)

    def test_normalized_mutual_information_bad_input(self):
        self.assertEqual(normalized_mutual_information(["a"], []), 0.0)

    def test_cross_scale_persistence_count(self):
        self.assertEqual(len(self.atlas["cross_scale_persistence"]), len(self.atlas["scales"]) - 1)

    def test_multiscale_has_multiple_levels(self):
        self.assertGreaterEqual(len(self.atlas["scales"]), 2)

    def test_selected_scale_exists(self):
        ids = {x["scale_id"] for x in self.atlas["scales"]}
        self.assertIn(self.atlas["selected_scale_id"], ids)

    def test_selected_scale_helper(self):
        self.assertEqual(selected_scale(self.atlas)["scale_id"], self.atlas["selected_scale_id"])

    def test_multiscale_invalid_bins(self):
        with self.assertRaises(ValueError):
            analyze_multiscale(self.substrate, bins=[2])
        with self.assertRaises(ValueError):
            analyze_multiscale(self.substrate, bins=[1, 2])

    def test_multiscale_deterministic(self):
        self.assertEqual(analyze_multiscale(self.substrate)["atlas_id"], self.atlas["atlas_id"])

    def test_concept_count_positive(self):
        self.assertGreater(self.concepts["concept_count"], 0)

    def test_concept_count_not_exceed_states(self):
        self.assertLessEqual(self.concepts["concept_count"], self.concepts["state_count"])

    def test_concept_frequency_sums_events(self):
        self.assertEqual(sum(self.concepts["concept_frequency"].values()), 360)

    def test_concept_sequence_length(self):
        self.assertEqual(len(self.concepts["concept_sequence"]), 360)

    def test_every_state_is_mapped(self):
        self.assertEqual(len(self.concepts["state_to_concept"]), self.concepts["state_count"])

    def test_opaque_symbols_have_no_names(self):
        for concept in self.concepts["concepts"]:
            self.assertTrue(concept["opaque_symbol"].startswith("ξ:"))
            self.assertIsNone(concept["machine_native_definition"]["human_label"])
            self.assertFalse(concept["machine_native_definition"]["definition_uses_human_language"])

    def test_concept_relative_support_sums_one(self):
        self.assertAlmostEqual(sum(c["relative_support"] for c in self.concepts["concepts"]), 1.0, places=8)

    def test_invalid_concept_threshold(self):
        with self.assertRaises(ValueError):
            discover_concepts(self.substrate, self.scale, distance_threshold=0.0)
        with self.assertRaises(ValueError):
            discover_concepts(self.substrate, self.scale, distance_threshold=1.0)

    def test_concept_discovery_deterministic(self):
        again = discover_concepts(self.substrate, self.scale)
        self.assertEqual(again["discovery_id"], self.concepts["discovery_id"])


class TestModelsCausalityAndOpacity(PipelineFixture):
    def test_world_model_count(self):
        self.assertEqual(self.models["model_count"], 8)

    def test_world_model_families_non_isomorphic(self):
        self.assertEqual(len(self.models["non_isomorphic_model_families"]), 8)

    def test_no_single_model_final_authority(self):
        self.assertFalse(self.models["single_model_final_authority"])

    def test_world_models_have_null_truth_certificate(self):
        self.assertTrue(all(m["truth_certificate"] is None for m in self.models["models"]))

    def test_world_model_ranks_unique(self):
        ranks = [m["rank_by_mdl"] for m in self.models["models"]]
        self.assertEqual(sorted(ranks), list(range(1, 9)))

    def test_world_model_probabilities_sum_one(self):
        for model in self.models["models"]:
            self.assertAlmostEqual(sum(model["next_distribution_from_last_context"].values()), 1.0, places=8)

    def test_world_model_disagreement_nonnegative(self):
        self.assertGreaterEqual(self.models["maximum_prediction_disagreement_bits"], 0.0)

    def test_causal_candidates_are_not_proofs(self):
        self.assertTrue(all(not h["causal_proof"] for h in self.causal["intervention_hypotheses"]))
        self.assertIsNone(self.causal["causal_certificate"])

    def test_causal_no_intervention_authority(self):
        self.assertEqual(self.causal["automatic_intervention_authority"], 0)

    def test_lagged_association_count(self):
        self.assertGreater(self.causal["lagged_association_count"], 0)

    def test_opacity_label_invariance(self):
        self.assertTrue(self.opacity["label_permutation_certificate"]["passed"])

    def test_opacity_does_not_claim_impossibility(self):
        self.assertFalse(self.opacity["human_comprehension_impossibility_claim"])
        self.assertIsNone(self.opacity["ultimate_truth_certificate"])

    def test_opacity_has_multiple_budgets(self):
        budgets = [x["budget"] for x in self.opacity["projection_certificates"]]
        self.assertEqual(budgets, sorted(set(budgets)))

    def test_projection_fidelity_bounded(self):
        for cert in self.opacity["projection_certificates"]:
            self.assertGreaterEqual(cert["predictive_fidelity"], 0.0)
            self.assertLessEqual(cert["predictive_fidelity"], 1.0)

    def test_full_budget_has_no_merged_concepts(self):
        cert = max(self.opacity["projection_certificates"], key=lambda x: x["budget"])
        if cert["budget"] == self.opacity["concept_count"]:
            self.assertEqual(cert["merged_concept_count"], 0)

    def test_custom_budgets_are_normalized(self):
        op = build_transcomprehension_certificates(self.raw, self.substrate, self.concepts, budgets=[0, 2, 999, 2])
        budgets = [x["budget"] for x in op["projection_certificates"]]
        self.assertEqual(budgets, sorted(set(budgets)))
        self.assertGreaterEqual(min(budgets), 1)
        self.assertLessEqual(max(budgets), self.concepts["concept_count"])


class TestGovernanceAndCompilation(PipelineFixture):
    def test_handshake_is_offline(self):
        self.assertFalse(self.handshake["transmission_authorized"])
        self.assertEqual(self.handshake["automatic_external_action_authority"], 0)

    def test_handshake_requires_no_language(self):
        self.assertFalse(self.handshake["natural_language_required"])
        self.assertFalse(self.handshake["shared_human_semantics_assumed"])

    def test_handshake_does_not_prove_consciousness(self):
        self.assertFalse(self.handshake["consciousness_proved_by_response"])
        self.assertFalse(self.handshake["mathematical_intelligence_proved_by_response"])

    def test_handshake_deterministic(self):
        again = build_cosmic_handshake(self.substrate["core_digest"], self.scale["invariants"]["structural_fingerprint"])
        self.assertEqual(again["handshake_id"], self.handshake["handshake_id"])

    def test_metamorphosis_not_applied(self):
        self.assertTrue(all(not p["automatically_applied"] for p in self.meta["proposals"]))
        self.assertTrue(all(p["status"] == "pending_named_review" for p in self.meta["proposals"]))

    def test_metamorphosis_authority_zero(self):
        self.assertEqual(self.meta["automatic_self_modification_authority"], 0)
        self.assertEqual(self.meta["self_generated_code_execution_authority"], 0)

    def test_bridge_closes_all_entities(self):
        self.assertEqual(self.bridge["entity_count"], len(self.bridge["records"]))
        self.assertEqual(set(self.bridge["governed_entity_ids"]), {r["entity_id"] for r in self.bridge["records"]})

    def test_bridge_outside_residual_zero(self):
        self.assertEqual(self.bridge["contract"]["out_of_space_residual"], 0.0)
        self.assertFalse(self.bridge["contract"]["permanent_untranslatable_outside_zone"])

    def test_bridge_does_not_replace_core(self):
        self.assertTrue(self.bridge["contract"]["dikwp_projection_is_not_core_replacement"])
        self.assertTrue(all(not r["core_replaced_by_projection"] for r in self.bridge["records"]))

    def test_bridge_vectors_sum_one(self):
        for record in self.bridge["records"]:
            self.assertAlmostEqual(sum(record["dikwp_vector"].values()), 1.0, places=8)
            self.assertAlmostEqual(sum(record["dikwp_family_vector"].values()), 1.0, places=8)

    def test_cosmonoesis_import_is_interface(self):
        imported = import_cosmonoesis_bridge()
        self.assertTrue(imported["import_is_interface_not_truth_transfer"])
        self.assertEqual(imported["automatic_external_action_authority"], 0)

    def test_report_contains_core_boundary(self):
        fake = self._minimal_bundle_for_render()
        report = render_report(fake)
        self.assertIn("不是被当作宇宙本体核心", report)
        self.assertIn("超理解", report)

    def test_dashboard_has_no_external_script(self):
        fake = self._minimal_bundle_for_render()
        dashboard = render_dashboard(fake)
        self.assertNotIn("<script src=", dashboard.lower())
        self.assertIn("Automatic external action authority 0", dashboard)

    def _minimal_bundle_for_render(self):
        # Build once so the source-only archive does not depend on pre-generated outputs.
        if not hasattr(self.__class__, "_render_bundle"):
            with tempfile.TemporaryDirectory() as tmp:
                self.__class__._render_bundle = compile_system(Path(tmp) / "render")
        return self.__class__._render_bundle

    def test_system_metadata(self):
        self.assertIn("APEIRON", SYSTEM_NAME)
        self.assertEqual(VERSION, "1.0.0")
        self.assertTrue(MESH_MODE.startswith("MESH95_"))

    def test_full_compile_and_verify(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "compiled"
            bundle = compile_system(out)
            result = verify_output_dir(out)
            self.assertTrue(result["valid"], result["errors"])
            self.assertEqual(bundle["automatic_external_action_authority"], 0)
            self.assertEqual(bundle["automatic_self_modification_authority"], 0)

    def test_compilation_is_content_deterministic(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = compile_system(Path(tmp) / "a")
            b = compile_system(Path(tmp) / "b")
            self.assertEqual(a["compilation_id"], b["compilation_id"])
            self.assertEqual(a["core_artifact"]["core_digest"], b["core_artifact"]["core_digest"])
            self.assertEqual(a["bundle_digest"], b["bundle_digest"])

    def test_manifest_detects_tampering(self):
        with tempfile.TemporaryDirectory() as tmp:
            out = Path(tmp) / "compiled"
            compile_system(out)
            (out / "COSMIC_SYSTEM_REPORT_CN.md").write_text("tampered", encoding="utf-8")
            result = verify_output_dir(out)
            self.assertFalse(result["valid"])
            self.assertTrue(any("Digest mismatch" in x for x in result["errors"]))

    def test_manifest_for_excludes_manifest_and_verify(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.txt").write_text("a")
            (root / "MANIFEST.json").write_text("x")
            (root / "VERIFY.txt").write_text("x")
            manifest = manifest_for(root)
            self.assertEqual(manifest["file_count"], 1)


if __name__ == "__main__":
    unittest.main()
