from __future__ import annotations

from collections import Counter, defaultdict
import math
from typing import Any

from .utils import entropy_from_counts, euclidean, js_divergence, mean, normalize_distribution, stable_id


def _state_profiles(substrate: dict[str, Any], scale: dict[str, Any]) -> dict[str, dict[str, Any]]:
    seq = scale["state_space"]["sequence"]
    centroids = scale["state_space"]["state_centroids"]
    events = substrate["core"]["events"]
    next_counts: dict[str, Counter[str]] = defaultdict(Counter)
    action_next: dict[str, Counter[tuple[int, str]]] = defaultdict(Counter)
    frequencies = Counter(seq)
    for i in range(len(seq) - 1):
        next_counts[seq[i]][seq[i + 1]] += 1
        action_next[seq[i]][(events[i]["action_code"], seq[i + 1])] += 1
    profiles: dict[str, dict[str, Any]] = {}
    for state in sorted(frequencies):
        profiles[state] = {
            "frequency": frequencies[state],
            "relative_frequency": frequencies[state] / len(seq),
            "centroid": centroids[state],
            "next_distribution": normalize_distribution(dict(next_counts[state])) if next_counts[state] else {state: 1.0},
            "action_next_distribution": normalize_distribution({f"{a}:{n}": c for (a, n), c in action_next[state].items()}) if action_next[state] else {},
            "next_entropy_bits": entropy_from_counts(next_counts[state].values()),
        }
    return profiles


def _profile_distance(a: dict[str, Any], b: dict[str, Any], dimension_count: int) -> float:
    predictive = js_divergence(a["next_distribution"], b["next_distribution"])
    intervention = js_divergence(a["action_next_distribution"], b["action_next_distribution"])
    geometric = euclidean(a["centroid"], b["centroid"]) / max(1.0, math.sqrt(dimension_count))
    frequency = abs(a["relative_frequency"] - b["relative_frequency"])
    return 0.55 * predictive + 0.15 * intervention + 0.22 * geometric + 0.08 * frequency


def discover_concepts(
    substrate: dict[str, Any],
    scale: dict[str, Any],
    *,
    distance_threshold: float = 0.31,
    minimum_support: int = 1,
) -> dict[str, Any]:
    if not 0.0 < distance_threshold < 1.0:
        raise ValueError("distance_threshold must be between 0 and 1")
    profiles = _state_profiles(substrate, scale)
    dimension_count = substrate["core"]["dimension_count"]
    ordered = sorted(profiles, key=lambda state: (-profiles[state]["frequency"], state))
    remaining = set(ordered)
    clusters: list[list[str]] = []

    for seed in ordered:
        if seed not in remaining:
            continue
        cluster = [seed]
        remaining.remove(seed)
        candidates = sorted(remaining, key=lambda state: (_profile_distance(profiles[seed], profiles[state], dimension_count), state))
        for candidate in candidates:
            distances = [_profile_distance(profiles[member], profiles[candidate], dimension_count) for member in cluster]
            if mean(distances) <= distance_threshold:
                cluster.append(candidate)
                remaining.remove(candidate)
        clusters.append(sorted(cluster))

    state_to_concept: dict[str, str] = {}
    concepts: list[dict[str, Any]] = []
    total_events = len(scale["state_space"]["sequence"])
    state_count = len(profiles)
    for members in clusters:
        support = sum(profiles[state]["frequency"] for state in members)
        if support < minimum_support:
            continue
        weights = [profiles[state]["frequency"] for state in members]
        weight_total = sum(weights)
        centroid = [
            round(sum(profiles[state]["centroid"][j] * profiles[state]["frequency"] for state in members) / weight_total, 12)
            for j in range(dimension_count)
        ]
        next_counts: Counter[str] = Counter()
        action_counts: Counter[str] = Counter()
        for state in members:
            for key, probability in profiles[state]["next_distribution"].items():
                next_counts[key] += probability * profiles[state]["frequency"]
            for key, probability in profiles[state]["action_next_distribution"].items():
                action_counts[key] += probability * profiles[state]["frequency"]
        payload = {
            "scale_id": scale["scale_id"],
            "members": members,
            "centroid": centroid,
            "predictive_distribution": {k: round(v, 12) for k, v in normalize_distribution(dict(next_counts)).items()},
            "action_signature": {k: round(v, 12) for k, v in normalize_distribution(dict(action_counts)).items()} if action_counts else {},
        }
        concept_id = stable_id("xi", payload, length=24)
        for state in members:
            state_to_concept[state] = concept_id
        within = []
        for i, left in enumerate(members):
            for right in members[i + 1:]:
                within.append(_profile_distance(profiles[left], profiles[right], dimension_count))
        concepts.append({
            "concept_id": concept_id,
            "opaque_symbol": f"ξ:{concept_id.split('-', 1)[1]}",
            "scale_id": scale["scale_id"],
            "member_state_ids": members,
            "support": support,
            "relative_support": round(support / total_events, 12),
            "state_compression_ratio": round(len(members) / max(1, state_count), 12),
            "centroid": centroid,
            "predictive_distribution": payload["predictive_distribution"],
            "action_signature": payload["action_signature"],
            "within_cluster_distance": round(mean(within), 12),
            "machine_native_definition": {
                "extension_digest": stable_id("ext", members),
                "predictive_equivalence_tolerance": distance_threshold,
                "definition_uses_human_language": False,
                "human_label": None,
            },
        })

    sequence = [state_to_concept[state] for state in scale["state_space"]["sequence"]]
    concept_counts = Counter(sequence)
    baseline_bits = len(sequence) * math.log2(max(1, state_count))
    concept_bits = len(sequence) * math.log2(max(1, len(concepts))) + state_count * math.log2(max(2, len(concepts) + 1))
    compression_gain = baseline_bits - concept_bits
    next_entropy = entropy_from_counts(Counter(sequence[1:]).values())
    conditional = 0.0
    transitions: dict[str, Counter[str]] = defaultdict(Counter)
    for a, b in zip(sequence[:-1], sequence[1:]):
        transitions[a][b] += 1
    total = max(1, len(sequence) - 1)
    for counts in transitions.values():
        conditional += (sum(counts.values()) / total) * entropy_from_counts(counts.values())

    return {
        "discovery_id": stable_id("concepts", {
            "substrate": substrate["core_digest"],
            "scale": scale["scale_id"],
            "threshold": distance_threshold,
            "assignments": state_to_concept,
        }),
        "scale_id": scale["scale_id"],
        "distance_threshold": distance_threshold,
        "state_count": state_count,
        "concept_count": len(concepts),
        "concepts": sorted(concepts, key=lambda x: (-x["support"], x["concept_id"])),
        "state_to_concept": dict(sorted(state_to_concept.items())),
        "concept_sequence": sequence,
        "concept_frequency": {k: v for k, v in sorted(concept_counts.items())},
        "compression_gain_bits": round(compression_gain, 12),
        "predictive_information_bits": round(max(0.0, next_entropy - conditional), 12),
        "language_required": False,
        "semantic_name_required": False,
        "concept_identity_is_operational_not_metaphysical": True,
    }
