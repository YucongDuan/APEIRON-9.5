from __future__ import annotations

import csv
from pathlib import Path
import shutil
from typing import Any

from .bridge import build_dikwp_bridge
from .causal import discover_causal_hypotheses
from .concepts import discover_concepts
from .handshake import build_cosmic_handshake
from .metamorphosis import propose_metamorphoses
from .multiscale import analyze_multiscale, selected_scale
from .opacity import build_transcomprehension_certificates
from .render import render_dashboard, render_report
from .substrate import build_substrate
from .utils import load_bundled_json, load_json, manifest_for, save_json, save_text, sha256_obj, stable_id, utc_now, write_apx
from .worldmodels import fit_world_model_ensemble

SYSTEM_NAME = "DIKWP-APEIRON 9.5 — Open-Ended Ontic Substrate, Trans-Semantic Discovery and Verifiable Beyond-Human World Modeling System"
VERSION = "1.0.0"
MESH_MODE = "MESH95_ASYMMETRY_PROTECTIVE_AGENCY_NONPSEUDONEUTRAL_RESPONSIBILITY_CLOSURE"


def _prepare_output(out: Path) -> None:
    if out.exists():
        for path in out.iterdir():
            if path.name == ".gitkeep":
                continue
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
    out.mkdir(parents=True, exist_ok=True)


def _write_concepts_csv(path: Path, concepts: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["concept_id", "opaque_symbol", "support", "relative_support", "member_state_count", "within_cluster_distance", "human_label"])
        for item in concepts["concepts"]:
            writer.writerow([item["concept_id"], item["opaque_symbol"], item["support"], item["relative_support"], len(item["member_state_ids"]), item["within_cluster_distance"], ""])


def _write_models_csv(path: Path, models: dict[str, Any]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.writer(fh)
        writer.writerow(["rank", "model_id", "model_name", "family", "test_log_loss_bits", "mdl_total_bits", "mdl_gain_vs_zero_order_bits", "retirement_candidate"])
        for item in models["models"]:
            writer.writerow([item["rank_by_mdl"], item["model_id"], item["model_name"], item["family"], item["average_test_log_loss_bits"], item["mdl_total_bits"], item["mdl_gain_vs_zero_order_bits"], item["retirement_candidate"]])


def compile_system(
    out_dir: str | Path,
    *,
    stream_path: str | Path | None = None,
    cosmonoesis_path: str | Path | None = None,
    bins: list[int] | None = None,
    concept_distance_threshold: float = 0.31,
) -> dict[str, Any]:
    out = Path(out_dir)
    _prepare_output(out)
    raw_stream = load_json(stream_path) if stream_path else load_bundled_json("demo_stream.json")
    substrate = build_substrate(raw_stream)
    atlas = analyze_multiscale(substrate, bins=bins)
    scale = selected_scale(atlas)
    concepts = discover_concepts(substrate, scale, distance_threshold=concept_distance_threshold)
    models = fit_world_model_ensemble(substrate, scale, concepts, atlas)
    causal = discover_causal_hypotheses(substrate)
    opacity = build_transcomprehension_certificates(raw_stream, substrate, concepts)
    structural_fingerprint = scale["invariants"]["structural_fingerprint"]

    machine_core = {
        "format": "APX95_NONLINGUISTIC_CORE_1.0",
        "substrate_core": substrate["core"],
        "multiscale_structures": [{
            "scale_id": item["scale_id"],
            "bins": item["bins"],
            "state_space": item["state_space"],
            "invariants": item["invariants"],
            "selection_score": item["selection_score"],
        } for item in atlas["scales"]],
        "machine_native_concepts": concepts,
        "world_model_descriptors": [{
            "model_id": item["model_id"],
            "family": item["family"],
            "descriptor": item["descriptor"],
            "mdl_total_bits": item["mdl_total_bits"],
            "next_distribution_from_last_context": item["next_distribution_from_last_context"],
        } for item in models["models"]],
        "causal_candidates": causal,
        "core_contract": {
            "human_labels_in_core": False,
            "natural_language_required": False,
            "semantic_names_required": False,
            "replayable": True,
            "ultimate_truth_claim": False,
        },
    }
    core_digest = sha256_obj(machine_core)
    handshake = build_cosmic_handshake(core_digest, structural_fingerprint)
    metamorphosis = propose_metamorphoses(atlas, concepts, models, causal, opacity)
    bridge = build_dikwp_bridge(
        substrate, atlas, concepts, models, causal,
        opacity=opacity, handshake=handshake, metamorphosis=metamorphosis,
        cosmonoesis_path=cosmonoesis_path,
    )
    research_basis = load_bundled_json("research_basis.json")
    governance = load_bundled_json("governance_invariants.json")
    boundary_ontology = load_bundled_json("dikwp_boundary.json")
    model_registry = load_bundled_json("model_registry.json")
    invariants_registry = load_bundled_json("invariants_registry.json")

    compilation_payload = {
        "core_digest": core_digest,
        "bridge_id": bridge["bridge_id"],
        "opacity": opacity["certificate_set_id"],
        "handshake": handshake["handshake_id"],
        "mesh_mode": MESH_MODE,
        "version": VERSION,
    }
    compilation_id = stable_id("apeiron", compilation_payload, length=24)
    bundle: dict[str, Any] = {
        "system": SYSTEM_NAME,
        "version": VERSION,
        "generated_at": utc_now(),
        "compilation_id": compilation_id,
        "mesh_mode": MESH_MODE,
        "design_thesis": {
            "language_is_interface_not_ontology": True,
            "semantic_projection_is_governance_not_core_replacement": True,
            "beyond_human_claim_is_decoder_relative": True,
            "ultimate_means_open_ended_reality_correctable_closure": True,
        },
        "ontic_event_lattice": substrate,
        "multiscale_atlas": atlas,
        "machine_native_concepts": concepts,
        "world_model_ensemble": models,
        "causal_hypotheses": causal,
        "transcomprehension_certificates": opacity,
        "cosmic_handshake_protocol": handshake,
        "metamorphosis_register": metamorphosis,
        "dikwp_boundary_bridge": bridge,
        "research_basis": research_basis,
        "governance_invariants": governance,
        "dikwp_boundary_ontology": boundary_ontology,
        "model_registry": model_registry,
        "invariants_registry": invariants_registry,
        "core_artifact": {
            "format": "APX95",
            "path": "apeiron_core.apx",
            "core_digest": core_digest,
            "human_labels_excluded": True,
            "canonical_json_sha256": core_digest,
        },
        "claim_boundaries": [
            "No final physical, metaphysical or consciousness truth is certified.",
            "Machine opacity is not evidence of ontological superiority.",
            "Prediction and compression gains do not by themselves establish causal truth.",
            "No machine-native concept automatically denotes consciousness, divinity, personhood or moral authority.",
            "Religious and civilizational mappings remain source-bound and do not imply historical identity.",
            "DIKWP normalization governs human consequences but does not erase the non-linguistic core.",
            "Any real-world transmission or intervention requires named, scoped and revocable authorization.",
        ],
        "bundle_digest_policy": {
            "algorithm": "sha256",
            "canonicalization": "UTF-8 canonical JSON with sorted keys and compact separators",
            "excluded_top_level_fields": ["generated_at", "bundle_digest"],
        },
        "automatic_external_action_authority": 0,
        "automatic_self_modification_authority": 0,
    }
    core_for_digest = dict(bundle)
    core_for_digest.pop("generated_at", None)
    bundle["bundle_digest"] = sha256_obj(core_for_digest)

    save_json(out / "apeiron_bundle.json", bundle)
    save_json(out / "ontic_event_lattice.json", substrate)
    save_json(out / "multiscale_atlas.json", atlas)
    save_json(out / "structural_invariants.json", {"scales": [{"scale_id": s["scale_id"], "bins": s["bins"], "invariants": s["invariants"]} for s in atlas["scales"]], "cross_scale_persistence": atlas["cross_scale_persistence"]})
    save_json(out / "machine_native_concepts.json", concepts)
    save_json(out / "world_model_ensemble.json", models)
    save_json(out / "causal_hypotheses.json", causal)
    save_json(out / "transcomprehension_certificates.json", opacity)
    save_json(out / "cosmic_handshake_protocol.json", handshake)
    save_json(out / "metamorphosis_register.json", metamorphosis)
    save_json(out / "dikwp_boundary_bridge.json", bridge)
    save_json(out / "research_basis.json", research_basis)
    save_json(out / "CORE_INFO.json", bundle["core_artifact"])
    write_apx(out / "apeiron_core.apx", machine_core)
    _write_concepts_csv(out / "machine_native_concepts.csv", concepts)
    _write_models_csv(out / "world_model_scores.csv", models)
    save_text(out / "COSMIC_SYSTEM_REPORT_CN.md", render_report(bundle))
    save_text(out / "dashboard.html", render_dashboard(bundle))

    manifest = manifest_for(out)
    save_json(out / "MANIFEST.json", manifest)
    from .verify import verify_output_dir
    verification = verify_output_dir(out)
    save_text(out / "VERIFY.txt", "VALID\n" + str(verification) + "\n" if verification["valid"] else "INVALID\n" + str(verification) + "\n")
    return bundle
