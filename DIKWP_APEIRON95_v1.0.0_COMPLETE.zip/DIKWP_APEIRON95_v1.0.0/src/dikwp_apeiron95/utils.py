from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from html import escape as html_escape
from importlib.resources import files
import hashlib
import json
import math
import re
import unicodedata
import zlib
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

APX_MAGIC = b"APX95\x00"


def utc_now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_text(text: str) -> str:
    return sha256_bytes(text.encode("utf-8"))


def sha256_obj(obj: Any) -> str:
    return sha256_text(canonical_json(obj))


def stable_id(prefix: str, obj: Any, length: int = 20) -> str:
    return f"{prefix}-{sha256_obj(obj)[:length]}"


def normalize_text(text: Any) -> str:
    value = unicodedata.normalize("NFKC", str(text or ""))
    value = value.replace("\u00a0", " ")
    value = re.sub(r"[\t\r ]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def load_json(path: str | Path) -> Any:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(path: str | Path, obj: Any) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    return str(p)


def save_text(path: str | Path, text: str) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return str(p)


def load_bundled_json(name: str) -> Any:
    resource = files("dikwp_apeiron95.data").joinpath(name)
    return json.loads(resource.read_text(encoding="utf-8"))


def clamp(value: Any, low: float = 0.0, high: float = 1.0) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return low
    return max(low, min(high, number))


def mean(values: Sequence[float]) -> float:
    return sum(values) / len(values) if values else 0.0


def variance(values: Sequence[float]) -> float:
    if not values:
        return 0.0
    m = mean(values)
    return sum((x - m) ** 2 for x in values) / len(values)


def stddev(values: Sequence[float]) -> float:
    return math.sqrt(variance(values))


def entropy_from_counts(counts: Iterable[int]) -> float:
    values = [int(x) for x in counts if int(x) > 0]
    total = sum(values)
    if total <= 0:
        return 0.0
    return -sum((c / total) * math.log2(c / total) for c in values)


def entropy_of(items: Iterable[Any]) -> float:
    return entropy_from_counts(Counter(items).values())


def conditional_entropy(pairs: Iterable[tuple[Any, Any]]) -> float:
    grouped: dict[Any, Counter[Any]] = {}
    count = 0
    for x, y in pairs:
        grouped.setdefault(x, Counter())[y] += 1
        count += 1
    if count == 0:
        return 0.0
    return sum((sum(c.values()) / count) * entropy_from_counts(c.values()) for c in grouped.values())


def normalize_distribution(weights: dict[Any, float], alpha: float = 0.0, support: Iterable[Any] | None = None) -> dict[Any, float]:
    keys = list(support) if support is not None else list(weights)
    if not keys:
        return {}
    cleaned = {k: max(0.0, float(weights.get(k, 0.0))) + alpha for k in keys}
    total = sum(cleaned.values())
    if total <= 0:
        return {k: 1.0 / len(keys) for k in keys}
    return {k: v / total for k, v in cleaned.items()}


def js_divergence(a: dict[Any, float], b: dict[Any, float]) -> float:
    keys = sorted(set(a) | set(b), key=str)
    if not keys:
        return 0.0
    pa = normalize_distribution(a, support=keys)
    pb = normalize_distribution(b, support=keys)
    m = {k: 0.5 * (pa[k] + pb[k]) for k in keys}

    def kl(p: dict[Any, float], q: dict[Any, float]) -> float:
        total = 0.0
        for k in keys:
            if p[k] > 0 and q[k] > 0:
                total += p[k] * math.log2(p[k] / q[k])
        return total

    return 0.5 * kl(pa, m) + 0.5 * kl(pb, m)


def cosine_dense(a: Sequence[float], b: Sequence[float]) -> float:
    if len(a) != len(b):
        raise ValueError("Dense vectors must have equal length")
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    return dot / (na * nb) if na and nb else 0.0


def euclidean(a: Sequence[float], b: Sequence[float]) -> float:
    if len(a) != len(b):
        raise ValueError("Dense vectors must have equal length")
    return math.sqrt(sum((x - y) ** 2 for x, y in zip(a, b)))


def pearson(a: Sequence[float], b: Sequence[float]) -> float:
    if len(a) != len(b) or len(a) < 2:
        return 0.0
    ma, mb = mean(a), mean(b)
    da = [x - ma for x in a]
    db = [x - mb for x in b]
    denom = math.sqrt(sum(x * x for x in da) * sum(y * y for y in db))
    return sum(x * y for x, y in zip(da, db)) / denom if denom else 0.0


def quantize(value: float, bins: int) -> int:
    if bins < 2:
        raise ValueError("bins must be >= 2")
    v = clamp(value)
    return min(bins - 1, int(v * bins))


def log_loss_bits(probability: float) -> float:
    return -math.log2(max(1e-15, min(1.0, probability)))


def html(value: Any) -> str:
    return html_escape(str(value if value is not None else ""), quote=True)


def iter_files(root: str | Path, *, exclude_names: set[str] | None = None) -> Iterator[Path]:
    base = Path(root)
    excluded = exclude_names or set()
    for path in sorted(base.rglob("*")):
        if path.is_file() and path.name not in excluded:
            yield path


def manifest_for(root: str | Path, *, exclude_names: set[str] | None = None) -> dict[str, Any]:
    base = Path(root)
    excluded = (exclude_names or set()) | {"MANIFEST.json", "VERIFY.txt"}
    records = []
    for path in iter_files(base, exclude_names=excluded):
        records.append({
            "path": path.relative_to(base).as_posix(),
            "bytes": path.stat().st_size,
            "sha256": sha256_bytes(path.read_bytes()),
        })
    result = {"algorithm": "sha256", "file_count": len(records), "files": records}
    result["manifest_digest"] = sha256_obj(result)
    return result


def encode_apx(core: Any) -> bytes:
    payload = canonical_json(core).encode("utf-8")
    return APX_MAGIC + len(payload).to_bytes(8, "big") + zlib.compress(payload, level=9)


def decode_apx(data: bytes) -> Any:
    if not data.startswith(APX_MAGIC):
        raise ValueError("Invalid APX95 magic header")
    if len(data) < len(APX_MAGIC) + 8:
        raise ValueError("Truncated APX95 file")
    expected = int.from_bytes(data[len(APX_MAGIC):len(APX_MAGIC) + 8], "big")
    payload = zlib.decompress(data[len(APX_MAGIC) + 8:])
    if len(payload) != expected:
        raise ValueError("APX95 payload length mismatch")
    return json.loads(payload.decode("utf-8"))


def write_apx(path: str | Path, core: Any) -> str:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(encode_apx(core))
    return str(p)


def round_floats(obj: Any, digits: int = 12) -> Any:
    if isinstance(obj, float):
        return round(obj, digits)
    if isinstance(obj, list):
        return [round_floats(x, digits) for x in obj]
    if isinstance(obj, tuple):
        return [round_floats(x, digits) for x in obj]
    if isinstance(obj, dict):
        return {str(k): round_floats(v, digits) for k, v in obj.items()}
    return obj
