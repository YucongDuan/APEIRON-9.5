from __future__ import annotations

from collections import Counter, defaultdict
import math
from typing import Any

from .utils import log_loss_bits, normalize_distribution, stable_id


def _projection_losses(sequence: list[str], budget: int, smoothing: float = 0.5) -> dict[str, Any]:
    n = len(sequence) - 1
    train_count = max(2, min(n - 1, int(n * 0.70)))
    support = sorted(set(sequence))
    frequencies = Counter(sequence[:train_count + 1])
    retained = [item for item, _ in frequencies.most_common(max(1, budget))]
    retained_set = set(retained)

    def projected(value: str) -> str:
        return value if value in retained_set else "OTHER"

    full_counts: dict[str, Counter[str]] = defaultdict(Counter)
    projection_counts: dict[str, Counter[str]] = defaultdict(Counter)
    global_counts = Counter(sequence[1:train_count + 1])
    for i in range(train_count):
        full_counts[sequence[i]][sequence[i + 1]] += 1
        projection_counts[projected(sequence[i])][sequence[i + 1]] += 1

    full_losses, projected_losses, witnesses = [], [], []
    for i in range(train_count, n):
        target = sequence[i + 1]
        full_dist = normalize_distribution(dict(full_counts.get(sequence[i]) or global_counts), alpha=smoothing, support=support)
        projected_dist = normalize_distribution(dict(projection_counts.get(projected(sequence[i])) or global_counts), alpha=smoothing, support=support)
        p_full = full_dist.get(target, 1e-15)
        p_proj = projected_dist.get(target, 1e-15)
        lf, lp = log_loss_bits(p_full), log_loss_bits(p_proj)
        full_losses.append(lf)
        projected_losses.append(lp)
        witnesses.append({
            "transition_index": i,
            "current_concept": sequence[i],
            "projected_current": projected(sequence[i]),
            "observed_next": target,
            "full_probability": round(p_full, 12),
            "projected_probability": round(p_proj, 12),
            "additional_loss_bits": round(lp - lf, 12),
        })
    full_avg = sum(full_losses) / len(full_losses) if full_losses else 0.0
    projected_avg = sum(projected_losses) / len(projected_losses) if projected_losses else 0.0
    delta = projected_avg - full_avg
    fidelity = math.exp(-max(0.0, delta))
    witnesses.sort(key=lambda x: (-x["additional_loss_bits"], x["transition_index"]))
    return {
        "budget": budget,
        "retained_concepts": retained,
        "merged_concept_count": max(0, len(support) - len(retained_set)),
        "full_average_log_loss_bits": round(full_avg, 12),
        "projected_average_log_loss_bits": round(projected_avg, 12),
        "additional_log_loss_bits": round(delta, 12),
        "predictive_fidelity": round(fidelity, 12),
        "witnesses": witnesses[:12],
    }


def build_transcomprehension_certificates(
    raw_stream: dict[str, Any],
    substrate: dict[str, Any],
    concepts: dict[str, Any],
    *,
    budgets: list[int] | None = None,
) -> dict[str, Any]:
    sequence = concepts["concept_sequence"]
    concept_count = len(set(sequence))
    candidate_budgets = budgets or [2, 4, 8, 16]
    normalized_budgets = sorted(set(max(1, min(concept_count, int(x))) for x in candidate_budgets))
    projections = [_projection_losses(sequence, budget) for budget in normalized_budgets]

    # Labels are replaced while observations/actions/times remain untouched.
    permuted = dict(raw_stream)
    dimension_count = substrate["core"]["dimension_count"]
    permuted["dimension_labels"] = [f"opaque_label_{dimension_count - i - 1}" for i in range(dimension_count)]
    from .substrate import build_substrate
    permuted_substrate = build_substrate(permuted)
    label_invariant = permuted_substrate["core_digest"] == substrate["core_digest"]

    for projection in projections:
        projection["gap_detected"] = (
            projection["budget"] < concept_count
            and projection["predictive_fidelity"] < 0.92
            and projection["additional_log_loss_bits"] > 0.05
        )
        projection["certificate_scope"] = "relative to this top-k tabular decoder and this event stream"
        projection["human_comprehension_impossibility_claim"] = False

    return {
        "certificate_set_id": stable_id("tcg", {
            "substrate": substrate["core_digest"],
            "concepts": concepts["discovery_id"],
            "projections": [(x["budget"], x["predictive_fidelity"]) for x in projections],
        }),
        "concept_count": concept_count,
        "projection_certificates": projections,
        "label_permutation_certificate": {
            "passed": label_invariant,
            "original_core_digest": substrate["core_digest"],
            "permuted_label_core_digest": permuted_substrate["core_digest"],
            "scope": "human dimension labels only",
            "claim": "the ontic core is independent of supplied human labels",
        },
        "any_transcomprehension_gap_detected": any(x["gap_detected"] for x in projections),
        "human_comprehension_impossibility_claim": False,
        "ultimate_truth_certificate": None,
        "interpretation": "A gap means the machine-native representation preserves predictive distinctions lost by a specified human-readable projection budget. It does not prove that humans can never understand the structure.",
        "automatic_external_action_authority": 0,
    }
