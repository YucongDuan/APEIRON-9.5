from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any

from .utils import mean, pearson, stable_id


def _sign(value: float, tolerance: float = 1e-9) -> int:
    return 1 if value > tolerance else -1 if value < -tolerance else 0


def discover_causal_hypotheses(substrate: dict[str, Any]) -> dict[str, Any]:
    events = substrate["core"]["events"]
    observations = [event["observation"] for event in events]
    actions = [event["action_code"] for event in events]
    environments = [event["environment_code"] for event in events]
    dimension_count = substrate["core"]["dimension_count"]
    deltas = [[observations[i + 1][j] - observations[i][j] for j in range(dimension_count)] for i in range(len(events) - 1)]
    action_support = Counter(actions[:-1])
    hypotheses: list[dict[str, Any]] = []

    all_means = [mean([row[j] for row in deltas]) for j in range(dimension_count)]
    for action in sorted(action_support):
        indices = [i for i, value in enumerate(actions[:-1]) if value == action]
        if len(indices) < 3:
            continue
        for j in range(dimension_count):
            action_mean = mean([deltas[i][j] for i in indices])
            effect = action_mean - all_means[j]
            env_effects = []
            for env in sorted(set(environments[:-1])):
                env_indices = [i for i in indices if environments[i] == env]
                other_indices = [i for i in range(len(deltas)) if environments[i] == env and actions[i] != action]
                if len(env_indices) >= 2 and len(other_indices) >= 2:
                    env_effects.append(mean([deltas[i][j] for i in env_indices]) - mean([deltas[i][j] for i in other_indices]))
            nonzero = [_sign(x) for x in env_effects if _sign(x) != 0]
            consistency = 0.0 if not nonzero else max(nonzero.count(1), nonzero.count(-1)) / len(nonzero)
            if abs(effect) < 0.025:
                continue
            payload = {"action": action, "coordinate": j, "effect": round(effect, 12), "support": len(indices)}
            hypotheses.append({
                "hypothesis_id": stable_id("ch", payload),
                "hypothesis_type": "intervention_association_candidate",
                "candidate_cause": f"a:{action}",
                "candidate_effect": f"q:{j}",
                "mean_delta_contrast": round(effect, 12),
                "support": len(indices),
                "environment_count_tested": len(env_effects),
                "environment_sign_consistency": round(consistency, 12),
                "confidence_proxy": round(min(1.0, len(indices) / 24.0) * (0.5 + 0.5 * consistency), 12),
                "causal_proof": False,
                "required_next_test": "randomized or naturally randomized intervention with held-out environments",
            })

    associations: list[dict[str, Any]] = []
    for source in range(dimension_count):
        x = [observations[i][source] for i in range(len(observations) - 1)]
        for target in range(dimension_count):
            if source == target:
                continue
            y = [deltas[i][target] for i in range(len(deltas))]
            corr = pearson(x, y)
            if abs(corr) >= 0.35:
                associations.append({
                    "association_id": stable_id("lag", {"source": source, "target": target, "corr": round(corr, 12)}),
                    "source_coordinate": f"q:{source}",
                    "next_delta_coordinate": f"Δq:{target}",
                    "lagged_correlation": round(corr, 12),
                    "causal_claim": False,
                })
    associations.sort(key=lambda item: (-abs(item["lagged_correlation"]), item["association_id"]))
    hypotheses.sort(key=lambda item: (-abs(item["mean_delta_contrast"]), item["hypothesis_id"]))
    return {
        "causal_discovery_id": stable_id("causal", {
            "substrate": substrate["core_digest"],
            "hypotheses": [x["hypothesis_id"] for x in hypotheses],
            "associations": [x["association_id"] for x in associations],
        }),
        "intervention_hypotheses": hypotheses,
        "lagged_associations": associations[:64],
        "causal_hypothesis_count": len(hypotheses),
        "lagged_association_count": len(associations),
        "causal_certificate": None,
        "observational_association_is_not_causation": True,
        "automatic_intervention_authority": 0,
    }
