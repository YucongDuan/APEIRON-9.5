from __future__ import annotations

from collections import Counter, defaultdict
import math
from typing import Any, Callable, Hashable

from .utils import js_divergence, log_loss_bits, normalize_distribution, stable_id

ContextFn = Callable[[int], Hashable]


def _fit_context_model(
    model_name: str,
    family: str,
    targets: list[str],
    context_fn: ContextFn,
    *,
    smoothing: float = 0.5,
) -> dict[str, Any]:
    n_transitions = len(targets) - 1
    if n_transitions < 3:
        raise ValueError("at least four states are required")
    train_count = max(2, min(n_transitions - 1, int(n_transitions * 0.70)))
    support = sorted(set(targets))
    counts: dict[Hashable, Counter[str]] = defaultdict(Counter)
    context_occurrences: Counter[Hashable] = Counter()
    for i in range(train_count):
        context = context_fn(i)
        counts[context][targets[i + 1]] += 1
        context_occurrences[context] += 1
    global_counts = Counter(targets[1:train_count + 1])

    losses = []
    predictions: list[dict[str, Any]] = []
    for i in range(train_count, n_transitions):
        context = context_fn(i)
        local = counts.get(context)
        distribution = normalize_distribution(dict(local or global_counts), alpha=smoothing, support=support)
        observed = targets[i + 1]
        probability = distribution.get(observed, 1e-15)
        loss = log_loss_bits(probability)
        losses.append(loss)
        if len(predictions) < 24:
            predictions.append({
                "transition_index": i,
                "observed": observed,
                "probability": round(probability, 12),
                "loss_bits": round(loss, 12),
                "top_predictions": sorted(
                    ({"state": state, "probability": round(p, 12)} for state, p in distribution.items()),
                    key=lambda x: (-x["probability"], x["state"]),
                )[:5],
            })
    average_loss = sum(losses) / len(losses) if losses else float("inf")
    parameter_count = max(1, len(counts) * max(1, len(support) - 1))
    complexity_bits = 0.5 * parameter_count * math.log2(train_count + 1)
    data_bits = average_loss * max(1, len(losses))
    mdl_bits = data_bits + complexity_bits
    last_index = n_transitions - 1
    last_context = context_fn(last_index)
    last_distribution = normalize_distribution(dict(counts.get(last_context) or global_counts), alpha=smoothing, support=support)

    descriptor = {
        "name": model_name,
        "family": family,
        "context_cardinality": len(counts),
        "target_cardinality": len(support),
        "smoothing": smoothing,
    }
    return {
        "model_id": stable_id("wm", descriptor),
        "model_name": model_name,
        "family": family,
        "descriptor": descriptor,
        "train_transition_count": train_count,
        "test_transition_count": len(losses),
        "average_test_log_loss_bits": round(average_loss, 12),
        "data_description_length_bits": round(data_bits, 12),
        "model_complexity_bits": round(complexity_bits, 12),
        "mdl_total_bits": round(mdl_bits, 12),
        "observed_context_count": len(counts),
        "parameter_count_proxy": parameter_count,
        "sample_predictions": predictions,
        "next_distribution_from_last_context": {k: round(v, 12) for k, v in sorted(last_distribution.items())},
        "truth_certificate": None,
        "semantic_interpretation_required": False,
    }


def _recurrence_model(sequence: list[str]) -> dict[str, Any]:
    n = len(sequence) - 1
    train_count = max(2, min(n - 1, int(n * 0.70)))
    persist = sum(sequence[i] == sequence[i + 1] for i in range(train_count))
    rate = (persist + 0.5) / (train_count + 1.0)
    support = sorted(set(sequence))
    losses = []
    for i in range(train_count, n):
        observed = sequence[i + 1]
        if observed == sequence[i]:
            probability = rate
        else:
            probability = (1.0 - rate) / max(1, len(support) - 1)
        losses.append(log_loss_bits(probability))
    avg = sum(losses) / len(losses) if losses else float("inf")
    complexity = 0.5 * math.log2(train_count + 1)
    data_bits = avg * max(1, len(losses))
    descriptor = {"name": "recurrence_process", "family": "persistence_process", "rate": round(rate, 12)}
    last = sequence[-1]
    distribution = {state: (rate if state == last else (1-rate)/max(1, len(support)-1)) for state in support}
    return {
        "model_id": stable_id("wm", descriptor),
        "model_name": "recurrence_process",
        "family": "persistence_process",
        "descriptor": descriptor,
        "train_transition_count": train_count,
        "test_transition_count": len(losses),
        "average_test_log_loss_bits": round(avg, 12),
        "data_description_length_bits": round(data_bits, 12),
        "model_complexity_bits": round(complexity, 12),
        "mdl_total_bits": round(data_bits + complexity, 12),
        "observed_context_count": 1,
        "parameter_count_proxy": 1,
        "sample_predictions": [],
        "next_distribution_from_last_context": {k: round(v, 12) for k, v in sorted(distribution.items())},
        "truth_certificate": None,
        "semantic_interpretation_required": False,
    }


def fit_world_model_ensemble(
    substrate: dict[str, Any],
    selected_scale: dict[str, Any],
    concepts: dict[str, Any],
    multiscale_atlas: dict[str, Any],
) -> dict[str, Any]:
    sequence = selected_scale["state_space"]["sequence"]
    events = substrate["core"]["events"]
    actions = [event["action_code"] for event in events]
    environments = [event["environment_code"] for event in events]
    concept_sequence = concepts["concept_sequence"]
    coarse_scale = min(multiscale_atlas["scales"], key=lambda x: x["bins"])
    coarse_sequence = coarse_scale["state_space"]["sequence"]

    models = [
        _fit_context_model("zero_order_frequency", "exchangeable_frequency", sequence, lambda i: ()),
        _fit_context_model("first_order_predictive_state", "predictive_state", sequence, lambda i: sequence[i]),
        _fit_context_model("action_conditioned_predictive_state", "controlled_predictive_state", sequence, lambda i: (sequence[i], actions[i])),
        _fit_context_model("second_order_process", "history_process", sequence, lambda i: (sequence[i-1] if i else "START", sequence[i], actions[i])),
        _fit_context_model("machine_concept_process", "opaque_concept_process", sequence, lambda i: concept_sequence[i]),
        _fit_context_model("multiscale_context_process", "cross_scale_process", sequence, lambda i: (coarse_sequence[i], actions[i])),
        _fit_context_model("environment_conditioned_process", "environment_specific_process", sequence, lambda i: (environments[i], sequence[i], actions[i])),
        _recurrence_model(sequence),
    ]
    ranked = sorted(models, key=lambda item: (item["mdl_total_bits"], item["average_test_log_loss_bits"], item["model_name"]))
    baseline = next(item for item in models if item["model_name"] == "zero_order_frequency")
    for rank, model in enumerate(ranked, 1):
        model["rank_by_mdl"] = rank
        model["mdl_gain_vs_zero_order_bits"] = round(baseline["mdl_total_bits"] - model["mdl_total_bits"], 12)
        model["retirement_candidate"] = model["mdl_total_bits"] > baseline["mdl_total_bits"] * 1.35 and model["model_name"] != "zero_order_frequency"

    pairwise = []
    for i, left in enumerate(ranked):
        for right in ranked[i + 1:]:
            divergence = js_divergence(left["next_distribution_from_last_context"], right["next_distribution_from_last_context"])
            pairwise.append({
                "left_model_id": left["model_id"],
                "right_model_id": right["model_id"],
                "next_prediction_js_divergence_bits": round(divergence, 12),
            })
    disagreement = max((item["next_prediction_js_divergence_bits"] for item in pairwise), default=0.0)
    payload = {
        "substrate": substrate["core_digest"],
        "scale": selected_scale["scale_id"],
        "models": [(m["model_id"], m["mdl_total_bits"]) for m in ranked],
    }
    return {
        "ensemble_id": stable_id("ensemble", payload),
        "model_count": len(models),
        "models": ranked,
        "best_model_id": ranked[0]["model_id"],
        "best_model_name": ranked[0]["model_name"],
        "baseline_model_id": baseline["model_id"],
        "pairwise_prediction_disagreement": pairwise,
        "maximum_prediction_disagreement_bits": round(disagreement, 12),
        "non_isomorphic_model_families": sorted(set(model["family"] for model in models)),
        "single_model_final_authority": False,
        "all_models_revisable": True,
        "automatic_model_retirement_authority": 0,
    }
