from __future__ import annotations

from collections import Counter, defaultdict, deque
import math
from typing import Any

from .utils import conditional_entropy, entropy_from_counts, mean, quantize, round_floats, sha256_obj, stable_id


def state_sequence(substrate: dict[str, Any], bins: int) -> dict[str, Any]:
    events = substrate["core"]["events"]
    states_raw = [tuple(quantize(v, bins) for v in event["observation"]) for event in events]
    unique = sorted(set(states_raw))
    # IDs depend on quantized structure, never on human labels.
    state_ids = {state: stable_id(f"s{bins}", list(state), length=16) for state in unique}
    sequence = [state_ids[state] for state in states_raw]
    centroids: dict[str, list[float]] = {}
    members: dict[str, list[int]] = defaultdict(list)
    for i, sid in enumerate(sequence):
        members[sid].append(i)
    for sid, indices in members.items():
        dim = len(events[0]["observation"])
        centroids[sid] = [round(mean([events[i]["observation"][j] for i in indices]), 12) for j in range(dim)]
    return {
        "bins": bins,
        "state_count": len(unique),
        "sequence": sequence,
        "state_values": {state_ids[state]: list(state) for state in unique},
        "state_centroids": centroids,
        "state_members": {k: v for k, v in sorted(members.items())},
        "sequence_digest": sha256_obj(sequence),
    }


def _connected_components(nodes: set[str], edges: set[tuple[str, str]]) -> int:
    adjacency: dict[str, set[str]] = {n: set() for n in nodes}
    for a, b in edges:
        adjacency[a].add(b)
        adjacency[b].add(a)
    seen: set[str] = set()
    count = 0
    for node in sorted(nodes):
        if node in seen:
            continue
        count += 1
        queue = deque([node])
        seen.add(node)
        while queue:
            current = queue.popleft()
            for nxt in adjacency[current]:
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
    return count


def analyze_scale(substrate: dict[str, Any], bins: int) -> dict[str, Any]:
    states = state_sequence(substrate, bins)
    seq = states["sequence"]
    actions = [event["action_code"] for event in substrate["core"]["events"]]
    environments = [event["environment_code"] for event in substrate["core"]["events"]]
    state_counts = Counter(seq)
    transitions = Counter(zip(seq[:-1], seq[1:]))
    action_transitions = Counter((seq[i], actions[i], seq[i + 1]) for i in range(len(seq) - 1))
    environment_transitions = Counter((environments[i], seq[i], seq[i + 1]) for i in range(len(seq) - 1))

    h_state = entropy_from_counts(state_counts.values())
    h_next_given_state = conditional_entropy(zip(seq[:-1], seq[1:]))
    h_next_given_state_action = conditional_entropy(((seq[i], actions[i]), seq[i + 1]) for i in range(len(seq) - 1))
    next_entropy = entropy_from_counts(Counter(seq[1:]).values())
    predictive_information = max(0.0, next_entropy - h_next_given_state)
    action_information_gain = max(0.0, h_next_given_state - h_next_given_state_action)
    persistence = sum(a == b for a, b in zip(seq[:-1], seq[1:])) / max(1, len(seq) - 1)
    recurrence = 1.0 - len(set(seq)) / max(1, len(seq))

    undirected_edges = {tuple(sorted((a, b))) for a, b in transitions if a != b}
    nodes = set(seq)
    components = _connected_components(nodes, undirected_edges)
    cycle_rank = max(0, len(undirected_edges) - len(nodes) + components)
    degrees = Counter()
    for a, b in undirected_edges:
        degrees[a] += 1
        degrees[b] += 1
    degree_sequence = sorted(degrees.get(node, 0) for node in nodes)

    transition_multiset = sorted(transitions.values())
    state_frequency_multiset = sorted(state_counts.values())
    structural_payload = {
        "bins": bins,
        "state_frequency_multiset": state_frequency_multiset,
        "transition_multiset": transition_multiset,
        "degree_sequence": degree_sequence,
        "cycle_rank": cycle_rank,
        "components": components,
        "state_entropy": round(h_state, 12),
        "conditional_entropy": round(h_next_given_state, 12),
    }
    fingerprint = sha256_obj(structural_payload)

    return {
        "scale_id": stable_id("scale", structural_payload),
        "bins": bins,
        "state_space": states,
        "invariants": {
            "event_count": len(seq),
            "state_count": len(nodes),
            "transition_type_count": len(transitions),
            "action_conditioned_transition_type_count": len(action_transitions),
            "environment_conditioned_transition_type_count": len(environment_transitions),
            "state_entropy_bits": round(h_state, 12),
            "next_state_entropy_bits": round(next_entropy, 12),
            "conditional_next_entropy_bits": round(h_next_given_state, 12),
            "conditional_next_entropy_given_action_bits": round(h_next_given_state_action, 12),
            "predictive_information_bits": round(predictive_information, 12),
            "action_information_gain_bits": round(action_information_gain, 12),
            "persistence_rate": round(persistence, 12),
            "recurrence_rate": round(recurrence, 12),
            "connected_components": components,
            "undirected_edge_count": len(undirected_edges),
            "cycle_rank": cycle_rank,
            "degree_sequence": degree_sequence,
            "state_frequency_multiset": state_frequency_multiset,
            "transition_count_multiset": transition_multiset,
            "structural_fingerprint": fingerprint,
        },
        "language_label_invariant_by_construction": True,
        "semantic_interpretation_required": False,
    }


def normalized_mutual_information(a: list[str], b: list[str]) -> float:
    if len(a) != len(b) or not a:
        return 0.0
    ca, cb = Counter(a), Counter(b)
    joint = Counter(zip(a, b))
    n = len(a)
    mi = 0.0
    for (x, y), count in joint.items():
        pxy = count / n
        px = ca[x] / n
        py = cb[y] / n
        mi += pxy * math.log2(pxy / (px * py))
    ha = entropy_from_counts(ca.values())
    hb = entropy_from_counts(cb.values())
    denom = math.sqrt(ha * hb)
    return mi / denom if denom else 1.0


def cross_scale_persistence(scales: list[dict[str, Any]]) -> list[dict[str, Any]]:
    out = []
    ordered = sorted(scales, key=lambda x: x["bins"])
    for left, right in zip(ordered[:-1], ordered[1:]):
        nmi = normalized_mutual_information(left["state_space"]["sequence"], right["state_space"]["sequence"])
        out.append({
            "from_bins": left["bins"],
            "to_bins": right["bins"],
            "normalized_mutual_information": round(nmi, 12),
            "interpretation": "partition persistence only; not ontological identity",
        })
    return out
