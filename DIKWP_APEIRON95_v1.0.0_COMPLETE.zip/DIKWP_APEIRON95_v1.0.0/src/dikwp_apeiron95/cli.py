from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
from typing import Any

from .bridge import build_dikwp_bridge
from .causal import discover_causal_hypotheses
from .compiler import MESH_MODE, SYSTEM_NAME, VERSION, compile_system
from .concepts import discover_concepts
from .handshake import build_cosmic_handshake
from .multiscale import analyze_multiscale, selected_scale
from .opacity import build_transcomprehension_certificates
from .substrate import build_substrate
from .utils import decode_apx, load_bundled_json, load_json, sha256_obj
from .verify import verify_output_dir
from .worldmodels import fit_world_model_ensemble


def _print(obj: Any) -> None:
    print(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False))


def _load_stream(path: str | None) -> dict[str, Any]:
    return load_json(path) if path else load_bundled_json("demo_stream.json")


def _pipeline(path: str | None, bins: list[int] | None = None, threshold: float = 0.31) -> tuple[dict[str, Any], ...]:
    raw = _load_stream(path)
    substrate = build_substrate(raw)
    atlas = analyze_multiscale(substrate, bins=bins)
    scale = selected_scale(atlas)
    concepts = discover_concepts(substrate, scale, distance_threshold=threshold)
    models = fit_world_model_ensemble(substrate, scale, concepts, atlas)
    causal = discover_causal_hypotheses(substrate)
    opacity = build_transcomprehension_certificates(raw, substrate, concepts)
    return raw, substrate, atlas, scale, concepts, models, causal, opacity


def cmd_doctor(_: argparse.Namespace) -> int:
    raw, substrate, atlas, scale, concepts, models, causal, opacity = _pipeline(None)
    result = {
        "valid": True,
        "system": SYSTEM_NAME,
        "version": VERSION,
        "mesh_mode": MESH_MODE,
        "python": sys.version.split()[0],
        "demo_event_count": substrate["statistics"]["event_count"],
        "selected_bins": atlas["selected_bins"],
        "machine_concept_count": concepts["concept_count"],
        "world_model_count": models["model_count"],
        "causal_candidate_count": causal["causal_hypothesis_count"],
        "label_invariance_passed": opacity["label_permutation_certificate"]["passed"],
        "automatic_external_action_authority": 0,
        "automatic_self_modification_authority": 0,
    }
    _print(result)
    return 0


def cmd_compile(args: argparse.Namespace) -> int:
    bundle = compile_system(
        args.out,
        stream_path=args.stream,
        cosmonoesis_path=args.cosmonoesis,
        bins=args.bins,
        concept_distance_threshold=args.threshold,
    )
    _print({
        "compiled": True,
        "out": str(Path(args.out).resolve()),
        "compilation_id": bundle["compilation_id"],
        "core_digest": bundle["core_artifact"]["core_digest"],
        "concept_count": bundle["machine_native_concepts"]["concept_count"],
        "world_model_count": bundle["world_model_ensemble"]["model_count"],
        "automatic_external_action_authority": 0,
    })
    return 0


def cmd_analyze(args: argparse.Namespace) -> int:
    _, substrate, atlas, scale, concepts, models, causal, opacity = _pipeline(args.stream, args.bins, args.threshold)
    _print({
        "substrate_core_digest": substrate["core_digest"],
        "event_count": substrate["statistics"]["event_count"],
        "dimension_count": substrate["statistics"]["dimension_count"],
        "selected_scale": {"scale_id": scale["scale_id"], "bins": scale["bins"], "invariants": scale["invariants"]},
        "concept_count": concepts["concept_count"],
        "concept_ids": [item["concept_id"] for item in concepts["concepts"]],
        "world_model_ranking": [{"name": item["model_name"], "family": item["family"], "mdl": item["mdl_total_bits"]} for item in models["models"]],
        "causal_candidate_count": causal["causal_hypothesis_count"],
        "transcomprehension_gap": opacity["any_transcomprehension_gap_detected"],
        "label_invariance_passed": opacity["label_permutation_certificate"]["passed"],
        "automatic_external_action_authority": 0,
    })
    return 0


def cmd_concepts(args: argparse.Namespace) -> int:
    _, _, _, _, concepts, _, _, _ = _pipeline(args.stream, args.bins, args.threshold)
    _print(concepts)
    return 0


def cmd_models(args: argparse.Namespace) -> int:
    _, _, _, _, _, models, _, _ = _pipeline(args.stream, args.bins, args.threshold)
    _print(models)
    return 0


def cmd_opacity(args: argparse.Namespace) -> int:
    raw, substrate, _, _, concepts, _, _, _ = _pipeline(args.stream, args.bins, args.threshold)
    budgets = args.budgets if args.budgets else None
    _print(build_transcomprehension_certificates(raw, substrate, concepts, budgets=budgets))
    return 0


def cmd_handshake(args: argparse.Namespace) -> int:
    _, substrate, atlas, scale, concepts, models, causal, _ = _pipeline(args.stream, args.bins, args.threshold)
    core_proxy = sha256_obj({
        "substrate": substrate["core_digest"],
        "atlas": atlas["atlas_id"],
        "concepts": concepts["discovery_id"],
        "models": models["ensemble_id"],
        "causal": causal["causal_discovery_id"],
    })
    _print(build_cosmic_handshake(core_proxy, scale["invariants"]["structural_fingerprint"]))
    return 0


def cmd_decode_core(args: argparse.Namespace) -> int:
    path = Path(args.path)
    core = decode_apx(path.read_bytes())
    if args.full:
        _print(core)
    else:
        _print({
            "path": str(path),
            "format": core.get("format"),
            "core_digest": sha256_obj(core),
            "event_count": core.get("substrate_core", {}).get("stream_length"),
            "dimension_count": core.get("substrate_core", {}).get("dimension_count"),
            "scale_count": len(core.get("multiscale_structures", [])),
            "concept_count": core.get("machine_native_concepts", {}).get("concept_count"),
            "human_labels_in_core": core.get("core_contract", {}).get("human_labels_in_core"),
        })
    return 0


def cmd_verify(args: argparse.Namespace) -> int:
    result = verify_output_dir(args.output)
    _print(result)
    return 0 if result["valid"] else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="apeiron95", description=SYSTEM_NAME)
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("doctor", help="Run deterministic internal checks")
    p.set_defaults(func=cmd_doctor)

    def add_analysis_options(p: argparse.ArgumentParser) -> None:
        p.add_argument("--stream", help="JSON event stream; defaults to bundled non-linguistic demo")
        p.add_argument("--bins", type=int, nargs="+", help="multiscale bin counts")
        p.add_argument("--threshold", type=float, default=0.31, help="machine-concept profile distance threshold")

    p = sub.add_parser("demo", help="Compile the bundled demonstration")
    p.add_argument("--out", default="outputs/apeiron_demo")
    p.add_argument("--cosmonoesis", help="optional COSMONOESIS95 bundle")
    p.add_argument("--bins", type=int, nargs="+")
    p.add_argument("--threshold", type=float, default=0.31)
    p.set_defaults(func=cmd_compile, stream=None)

    p = sub.add_parser("compile", help="Compile a non-linguistic event stream")
    p.add_argument("--stream", required=True)
    p.add_argument("--out", required=True)
    p.add_argument("--cosmonoesis", help="optional COSMONOESIS95 bundle")
    p.add_argument("--bins", type=int, nargs="+")
    p.add_argument("--threshold", type=float, default=0.31)
    p.set_defaults(func=cmd_compile)

    p = sub.add_parser("analyze", help="Return a compact structural analysis")
    add_analysis_options(p)
    p.set_defaults(func=cmd_analyze)

    p = sub.add_parser("concepts", help="Discover opaque machine-native concepts")
    add_analysis_options(p)
    p.set_defaults(func=cmd_concepts)

    p = sub.add_parser("models", help="Fit the non-isomorphic world-model ensemble")
    add_analysis_options(p)
    p.set_defaults(func=cmd_models)

    p = sub.add_parser("opacity", help="Issue decoder-relative transcomprehension certificates")
    add_analysis_options(p)
    p.add_argument("--budgets", type=int, nargs="+")
    p.set_defaults(func=cmd_opacity)

    p = sub.add_parser("handshake", help="Generate an offline label-free cosmic handshake candidate")
    add_analysis_options(p)
    p.set_defaults(func=cmd_handshake)

    p = sub.add_parser("decode-core", help="Decode an APX95 non-linguistic core artifact")
    p.add_argument("path")
    p.add_argument("--full", action="store_true")
    p.set_defaults(func=cmd_decode_core)

    p = sub.add_parser("verify", help="Verify a compiled output directory")
    p.add_argument("output")
    p.set_defaults(func=cmd_verify)
    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        code = args.func(args)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        _print({"error": str(exc), "automatic_external_action_authority": 0})
        code = 2
    raise SystemExit(code)
