from __future__ import annotations

from collections import Counter
from pathlib import Path
from typing import Any

from .utils import clamp, load_json, mean, normalize_text, round_floats, sha256_obj, stable_id


def _canonical_categories(values: list[Any]) -> tuple[list[int], list[dict[str, Any]]]:
    mapping: dict[str, int] = {}
    codes: list[int] = []
    metadata: list[dict[str, Any]] = []
    for value in values:
        key = sha256_obj({"opaque_category": value})
        # First-occurrence canonicalization makes renamed categories structurally equivalent.
        if key not in mapping:
            mapping[key] = len(mapping)
            metadata.append({"code": mapping[key], "source_digest": key})
        codes.append(mapping[key])
    return codes, metadata


def _validate_observation(raw: Any, index: int) -> list[float]:
    if not isinstance(raw, list) or not raw:
        raise ValueError(f"event {index}: observation must be a non-empty numeric array")
    out: list[float] = []
    for j, value in enumerate(raw):
        try:
            number = float(value)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"event {index}, coordinate {j}: non-numeric value") from exc
        if number != number or number in (float("inf"), float("-inf")):
            raise ValueError(f"event {index}, coordinate {j}: non-finite value")
        out.append(number)
    return out


def build_substrate(stream: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(stream, dict):
        raise ValueError("stream must be an object")
    events_raw = stream.get("events")
    if not isinstance(events_raw, list) or len(events_raw) < 4:
        raise ValueError("stream.events must contain at least four events")

    observations = [_validate_observation(item.get("observation"), i) for i, item in enumerate(events_raw)]
    dimensions = len(observations[0])
    if any(len(row) != dimensions for row in observations):
        raise ValueError("all observations must have the same dimensionality")

    labels = stream.get("dimension_labels")
    if labels is None:
        labels = [None] * dimensions
    if not isinstance(labels, list) or len(labels) != dimensions:
        raise ValueError("dimension_labels must be omitted or match observation dimensionality")

    times = [item.get("t", i) for i, item in enumerate(events_raw)]
    if any(not isinstance(x, (int, float)) for x in times):
        raise ValueError("event time values must be numeric")
    if any(times[i] >= times[i + 1] for i in range(len(times) - 1)):
        raise ValueError("event time values must be strictly increasing")

    actions_raw = [item.get("action", 0) for item in events_raw]
    environments_raw = [item.get("environment", 0) for item in events_raw]
    action_codes, action_metadata = _canonical_categories(actions_raw)
    environment_codes, environment_metadata = _canonical_categories(environments_raw)

    mins = [min(row[j] for row in observations) for j in range(dimensions)]
    maxs = [max(row[j] for row in observations) for j in range(dimensions)]
    normalized: list[list[float]] = []
    for row in observations:
        nr = []
        for j, value in enumerate(row):
            width = maxs[j] - mins[j]
            nr.append(0.5 if width == 0 else clamp((value - mins[j]) / width))
        normalized.append(nr)

    events: list[dict[str, Any]] = []
    uncertainties: list[float] = []
    for i, (raw, norm) in enumerate(zip(observations, normalized)):
        uncertainty = clamp(events_raw[i].get("uncertainty", stream.get("default_uncertainty", 0.0)))
        uncertainties.append(uncertainty)
        core_payload = {
            "index": i,
            "delta_t": 0.0 if i == 0 else round(float(times[i] - times[i - 1]), 12),
            "observation": [round(x, 12) for x in norm],
            "action_code": action_codes[i],
            "environment_code": environment_codes[i],
            "uncertainty": round(uncertainty, 12),
        }
        events.append({
            "event_id": stable_id("evt", core_payload),
            **core_payload,
            "raw_observation_digest": sha256_obj([round(x, 12) for x in raw]),
        })

    deltas = [
        [round(normalized[i][j] - normalized[i - 1][j], 12) for j in range(dimensions)]
        for i in range(1, len(normalized))
    ]
    action_counts = Counter(action_codes)
    environment_counts = Counter(environment_codes)

    core = {
        "stream_length": len(events),
        "dimension_count": dimensions,
        "events": events,
        "normalization": {
            "method": "coordinate_minmax",
            "constant_coordinate_value": 0.5,
        },
        "action_cardinality": len(action_metadata),
        "environment_cardinality": len(environment_metadata),
    }
    core_digest = sha256_obj(core)
    return {
        "system": "APEIRON95_ONTIC_EVENT_SUBSTRATE",
        "stream_id": normalize_text(stream.get("stream_id")) or stable_id("stream", core),
        "core_digest": core_digest,
        "core": core,
        "statistics": {
            "event_count": len(events),
            "dimension_count": dimensions,
            "coordinate_minima": [round(x, 12) for x in mins],
            "coordinate_maxima": [round(x, 12) for x in maxs],
            "mean_absolute_delta": round(mean([abs(x) for row in deltas for x in row]), 12),
            "mean_uncertainty": round(mean(uncertainties), 12),
            "action_counts": {str(k): v for k, v in sorted(action_counts.items())},
            "environment_counts": {str(k): v for k, v in sorted(environment_counts.items())},
        },
        "interface_metadata": {
            "dimension_labels": [normalize_text(x) if x is not None else None for x in labels],
            "labels_excluded_from_core_digest": True,
            "action_sources": action_metadata,
            "environment_sources": environment_metadata,
            "human_annotation": normalize_text(stream.get("human_annotation")),
        },
        "language_required_for_core": False,
        "semantic_interpretation_required_for_core": False,
        "human_labels_are_optional_interface": True,
        "automatic_external_action_authority": 0,
    }


def substrate_from_path(path: str | Path) -> dict[str, Any]:
    return build_substrate(load_json(path))


def relabel_stream(stream: dict[str, Any], labels: list[str]) -> dict[str, Any]:
    out = {**stream, "dimension_labels": list(labels)}
    return out


def core_digest_for_stream(stream: dict[str, Any]) -> str:
    return build_substrate(stream)["core_digest"]
