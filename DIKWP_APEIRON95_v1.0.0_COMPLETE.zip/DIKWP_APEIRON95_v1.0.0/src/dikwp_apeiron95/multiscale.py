from __future__ import annotations

import math
from collections import Counter, defaultdict
from typing import Any

from .invariants import analyze_scale, cross_scale_persistence
from .utils import log_loss_bits, normalize_distribution, stable_id


def _heldout_first_order_loss(scale: dict[str, Any]) -> float:
    sequence = scale["state_space"]["sequence"]
    n = len(sequence) - 1
    train_count = max(2, min(n - 1, int(n * 0.70)))
    support = sorted(set(sequence))
    counts: dict[str, Counter[str]] = defaultdict(Counter)
    global_counts = Counter(sequence[1:train_count + 1])
    for i in range(train_count):
        counts[sequence[i]][sequence[i + 1]] += 1
    losses = []
    for i in range(train_count, n):
        distribution = normalize_distribution(dict(counts.get(sequence[i]) or global_counts), alpha=0.5, support=support)
        losses.append(log_loss_bits(distribution.get(sequence[i + 1], 1e-15)))
    return sum(losses) / len(losses) if losses else float("inf")


def _scale_score(scale: dict[str, Any]) -> float:
    inv = scale["invariants"]
    heldout_loss = _heldout_first_order_loss(scale)
    singleton_fraction = sum(1 for count in inv["state_frequency_multiset"] if count == 1) / max(1, inv["state_count"])
    predictive_efficiency = inv["predictive_information_bits"] / max(1e-12, inv["next_state_entropy_bits"])
    action_efficiency = inv["action_information_gain_bits"] / max(1e-12, inv["next_state_entropy_bits"])
    score = (
        1.0 / (1.0 + heldout_loss)
        + 0.20 * predictive_efficiency
        + 0.10 * action_efficiency
        + 0.08 * inv["persistence_rate"]
        - 0.25 * singleton_fraction
    )
    scale["heldout_first_order_log_loss_bits"] = round(heldout_loss, 12)
    scale["singleton_state_fraction"] = round(singleton_fraction, 12)
    scale["predictive_efficiency"] = round(predictive_efficiency, 12)
    return round(score, 12)


def analyze_multiscale(substrate: dict[str, Any], bins: list[int] | None = None) -> dict[str, Any]:
    levels = bins or [2, 3, 4, 6, 8]
    if len(set(levels)) < 2 or any(int(x) < 2 for x in levels):
        raise ValueError("multiscale analysis requires at least two distinct bin counts >= 2")
    scales = [analyze_scale(substrate, int(level)) for level in sorted(set(levels))]
    for scale in scales:
        scale["selection_score"] = _scale_score(scale)
    ranked = sorted(scales, key=lambda x: (-x["selection_score"], x["bins"]))
    persistence = cross_scale_persistence(scales)
    result = {
        "atlas_id": stable_id("atlas", {
            "substrate": substrate["core_digest"],
            "scales": [(x["bins"], x["invariants"]["structural_fingerprint"]) for x in scales],
        }),
        "scales": scales,
        "cross_scale_persistence": persistence,
        "selected_scale_id": ranked[0]["scale_id"],
        "selected_bins": ranked[0]["bins"],
        "selection_ranking": [{
            "scale_id": x["scale_id"],
            "bins": x["bins"],
            "selection_score": x["selection_score"],
            "state_count": x["invariants"]["state_count"],
        } for x in ranked],
        "selection_is_pragmatic_not_metaphysical": True,
        "all_scales_preserved": True,
    }
    return result


def selected_scale(atlas: dict[str, Any]) -> dict[str, Any]:
    selected = atlas["selected_scale_id"]
    return next(x for x in atlas["scales"] if x["scale_id"] == selected)
