from __future__ import annotations

from typing import Any

from .utils import stable_id


def _proposal(kind: str, reason: str, patch: dict[str, Any], tests: list[str], risk: str) -> dict[str, Any]:
    payload = {"kind": kind, "reason": reason, "patch": patch, "tests": tests, "risk": risk}
    return {
        "proposal_id": stable_id("meta", payload),
        "kind": kind,
        "reason": reason,
        "reversible_parameter_patch": patch,
        "required_tests": tests,
        "risk_level": risk,
        "status": "pending_named_review",
        "automatically_applied": False,
    }


def propose_metamorphoses(
    multiscale: dict[str, Any],
    concepts: dict[str, Any],
    models: dict[str, Any],
    causal: dict[str, Any],
    opacity: dict[str, Any],
) -> dict[str, Any]:
    proposals: list[dict[str, Any]] = []
    ranking = multiscale["selection_ranking"]
    if len(ranking) >= 2 and abs(ranking[0]["selection_score"] - ranking[1]["selection_score"]) < 0.15:
        proposals.append(_proposal(
            "add_intermediate_scale",
            "two scales remain nearly tied",
            {"multiscale_bins_add": int(round((ranking[0]["bins"] + ranking[1]["bins"]) / 2))},
            ["label-permutation invariance", "held-out predictive MDL", "manifest integrity"],
            "low",
        ))
    if models["maximum_prediction_disagreement_bits"] > 0.15:
        proposals.append(_proposal(
            "seek_discriminating_intervention",
            "world models disagree on the next-state distribution",
            {"experiment_goal": "maximize expected pairwise prediction divergence", "external_execution": False},
            ["pre-register outcome criteria", "burden and reversibility review", "named authorization"],
            "medium",
        ))
    if causal["causal_hypothesis_count"]:
        proposals.append(_proposal(
            "cross_environment_causal_stress_test",
            "intervention-associated candidates exist but are not causally identified",
            {"new_environment_required": True, "randomization_preferred": True},
            ["confounding audit", "held-out environment sign consistency", "stop condition"],
            "medium",
        ))
    if opacity["any_transcomprehension_gap_detected"]:
        proposals.append(_proposal(
            "invent_new_human_decoder",
            "current human-readable top-k projections lose predictive distinctions",
            {"decoder_family": "relation_and_counterexample_first", "preserve_opaque_ids": True},
            ["projection fidelity improves", "no false equivalence", "original core unchanged"],
            "low",
        ))
    if concepts["compression_gain_bits"] < 0:
        proposals.append(_proposal(
            "split_or_retire_concept_partition",
            "current concept partition does not improve description length",
            {"distance_threshold_delta": -0.04},
            ["concept IDs deterministically regenerate", "predictive gain non-decreasing", "rollback available"],
            "low",
        ))
    if not proposals:
        proposals.append(_proposal(
            "collect_more_reality_contact",
            "no representation mutation is currently justified",
            {"append_observations": True, "change_core_rules": False},
            ["provenance", "uncertainty", "outcome return"],
            "low",
        ))
    return {
        "metamorphosis_register_id": stable_id("metareg", [x["proposal_id"] for x in proposals]),
        "proposal_count": len(proposals),
        "proposals": proposals,
        "self_generated_code_execution_authority": 0,
        "automatic_self_modification_authority": 0,
        "external_action_authority": 0,
        "approval_contract": "Only reversible parameter changes may be proposed; execution requires named review and successful tests.",
    }
