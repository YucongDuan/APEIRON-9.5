from __future__ import annotations

from typing import Any

from .utils import sha256_text, stable_id


def _seed_numbers(digest: str, count: int = 16) -> list[int]:
    raw = bytes.fromhex(digest)
    values = []
    for i in range(count):
        values.append(2 + raw[i % len(raw)] % 29)
    return values


def build_cosmic_handshake(core_digest: str, structural_fingerprint: str) -> dict[str, Any]:
    seed_digest = sha256_text(core_digest + structural_fingerprint)
    seed = _seed_numbers(seed_digest, 16)
    base = seed[:8]
    permutation = sorted(range(len(base)), key=lambda i: (base[i], i))
    inverse = [0] * len(permutation)
    for i, p in enumerate(permutation):
        inverse[p] = i
    recurrence = [base[i % len(base)] for i in range(24)]
    difference = [(recurrence[i + 1] - recurrence[i]) % 31 for i in range(len(recurrence) - 1)]
    composition = [(base[i] * base[(i + 1) % len(base)] + base[(i + 2) % len(base)]) % 31 for i in range(len(base))]
    packet = {
        "protocol": "APX95_LABEL_FREE_STRUCTURAL_HANDSHAKE",
        "stage_0_repetition": recurrence,
        "stage_1_permutation": {"input": base, "permutation": permutation, "inverse": inverse},
        "stage_2_difference": difference,
        "stage_3_composition_challenge": {"modulus": 31, "input": base, "expected_transform": composition},
        "stage_4_causal_echo": {
            "challenge_pairs": [[base[i], base[(i + 1) % len(base)]] for i in range(len(base))],
            "requested_operation_id": "opaque_transform_0",
            "success_condition": "repeatable response changes under controlled input variation",
        },
    }
    return {
        "handshake_id": stable_id("handshake", packet),
        "packet": packet,
        "natural_language_required": False,
        "shared_human_semantics_assumed": False,
        "mathematical_intelligence_proved_by_response": False,
        "consciousness_proved_by_response": False,
        "contact_stage": "candidate_offline_protocol_only",
        "transmission_authorized": False,
        "named_authorization_required_before_transmission": True,
        "automatic_external_action_authority": 0,
    }
