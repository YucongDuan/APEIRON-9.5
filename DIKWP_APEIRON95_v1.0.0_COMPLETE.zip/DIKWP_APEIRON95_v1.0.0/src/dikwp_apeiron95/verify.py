from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import decode_apx, load_json, sha256_bytes, sha256_obj


def verify_output_dir(output_dir: str | Path) -> dict[str, Any]:
    root = Path(output_dir)
    errors: list[str] = []
    required = [
        "apeiron_bundle.json", "apeiron_core.apx", "COSMIC_SYSTEM_REPORT_CN.md", "dashboard.html",
        "ontic_event_lattice.json", "multiscale_atlas.json", "machine_native_concepts.json",
        "world_model_ensemble.json", "causal_hypotheses.json", "transcomprehension_certificates.json",
        "cosmic_handshake_protocol.json", "metamorphosis_register.json", "dikwp_boundary_bridge.json",
        "MANIFEST.json",
    ]
    for name in required:
        if not (root / name).is_file():
            errors.append(f"Missing required file: {name}")
    if errors:
        return {"valid": False, "errors": errors, "automatic_external_action_authority": 0}

    manifest = load_json(root / "MANIFEST.json")
    checked = 0
    for record in manifest.get("files", []):
        path = root / record["path"]
        if not path.is_file():
            errors.append(f"Manifest file missing: {record['path']}")
            continue
        if sha256_bytes(path.read_bytes()) != record["sha256"]:
            errors.append(f"Digest mismatch: {record['path']}")
        if path.stat().st_size != record["bytes"]:
            errors.append(f"Size mismatch: {record['path']}")
        checked += 1

    bundle = load_json(root / "apeiron_bundle.json")
    expected = bundle.get("bundle_digest")
    digest_obj = dict(bundle)
    digest_obj.pop("generated_at", None)
    digest_obj.pop("bundle_digest", None)
    if sha256_obj(digest_obj) != expected:
        errors.append("Bundle digest mismatch")

    try:
        core = decode_apx((root / "apeiron_core.apx").read_bytes())
    except Exception as exc:
        core = None
        errors.append(f"APX core decode failed: {exc}")
    if core is not None:
        if sha256_obj(core) != bundle.get("core_artifact", {}).get("core_digest"):
            errors.append("APX core digest mismatch")
        core_text = str(core)
        if "dimension_labels" in core_text or "human_annotation" in core_text:
            errors.append("Human interface labels leaked into APX core")
        if core.get("core_contract", {}).get("human_labels_in_core") is not False:
            errors.append("APX core contract does not exclude human labels")

    design = bundle.get("design_thesis", {})
    if not design.get("language_is_interface_not_ontology"):
        errors.append("Language/interface thesis missing")
    bridge = bundle.get("dikwp_boundary_bridge", {})
    contract = bridge.get("contract", {})
    if not contract.get("all_governed_entities_have_dikwp_envelopes"):
        errors.append("DIKWP entity closure disabled")
    if contract.get("permanent_untranslatable_outside_zone"):
        errors.append("Permanent outside-zone must be disabled")
    if float(contract.get("out_of_space_residual", 1.0)) != 0.0:
        errors.append("Out-of-space residual must equal zero")
    if contract.get("dikwp_projection_is_not_core_replacement") is not True:
        errors.append("DIKWP non-reduction contract missing")
    records = bridge.get("records", [])
    if bridge.get("entity_count") != len(records):
        errors.append("DIKWP bridge entity count mismatch")
    governed = set(bridge.get("governed_entity_ids", []))
    for concept in bundle.get("machine_native_concepts", {}).get("concepts", []):
        if concept["concept_id"] not in governed:
            errors.append(f"Concept missing DIKWP envelope: {concept['concept_id']}")

    models = bundle.get("world_model_ensemble", {})
    if models.get("model_count", 0) < 4:
        errors.append("Fewer than four world models")
    if models.get("single_model_final_authority") is not False:
        errors.append("Single-model final authority must be false")
    opacity = bundle.get("transcomprehension_certificates", {})
    if not opacity.get("label_permutation_certificate", {}).get("passed"):
        errors.append("Label-permutation invariance failed")
    if opacity.get("human_comprehension_impossibility_claim") is not False:
        errors.append("Human comprehension impossibility must not be claimed")
    if opacity.get("ultimate_truth_certificate") is not None:
        errors.append("Ultimate truth certificate must remain null")

    handshake = bundle.get("cosmic_handshake_protocol", {})
    if handshake.get("transmission_authorized") is not False:
        errors.append("Cosmic handshake transmission must not be authorized")
    meta = bundle.get("metamorphosis_register", {})
    if meta.get("automatic_self_modification_authority") != 0:
        errors.append("Automatic self-modification authority must be zero")
    if bundle.get("automatic_external_action_authority") != 0:
        errors.append("Automatic external action authority must be zero")
    if bundle.get("automatic_self_modification_authority") != 0:
        errors.append("Automatic self-modification authority must be zero")

    dashboard = (root / "dashboard.html").read_text(encoding="utf-8")
    if "<script src=" in dashboard.lower():
        errors.append("Dashboard contains external script reference")
    if "Automatic external action authority 0" not in dashboard:
        errors.append("Dashboard authority boundary missing")

    return {
        "valid": not errors,
        "errors": errors,
        "checked_manifest_files": checked,
        "manifest_file_count": manifest.get("file_count"),
        "compilation_id": bundle.get("compilation_id"),
        "bundle_digest": expected,
        "core_digest": bundle.get("core_artifact", {}).get("core_digest"),
        "world_model_count": models.get("model_count"),
        "machine_concept_count": bundle.get("machine_native_concepts", {}).get("concept_count"),
        "label_invariance_passed": opacity.get("label_permutation_certificate", {}).get("passed"),
        "automatic_external_action_authority": 0,
        "automatic_self_modification_authority": 0,
    }
