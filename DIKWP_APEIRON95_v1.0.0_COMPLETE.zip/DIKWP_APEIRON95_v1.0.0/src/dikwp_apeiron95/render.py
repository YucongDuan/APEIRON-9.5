from __future__ import annotations

import json
from typing import Any

from .utils import html


def _pct(value: float) -> str:
    return f"{100 * float(value):.2f}%"


def render_report(bundle: dict[str, Any]) -> str:
    substrate = bundle["ontic_event_lattice"]
    atlas = bundle["multiscale_atlas"]
    concepts = bundle["machine_native_concepts"]
    models = bundle["world_model_ensemble"]
    causal = bundle["causal_hypotheses"]
    opacity = bundle["transcomprehension_certificates"]
    bridge = bundle["dikwp_boundary_bridge"]
    meta = bundle["metamorphosis_register"]
    best = models["models"][0]
    lines: list[str] = []
    lines.extend([
        "# DIKWP-APEIRON 9.5：宇宙终极开放系统",
        "",
        "## 无语言本体底座、超语义发现、超人类可核验世界模型与 DIKWP 责任闭包",
        "",
        f"- 编译标识：`{bundle['compilation_id']}`",
        f"- 非语言核心摘要：`{bundle['core_artifact']['core_digest']}`",
        f"- Mesh 模式：`{bundle['mesh_mode']}`",
        f"- 自动外部行动权限：`{bundle['automatic_external_action_authority']}`",
        "",
        "---",
        "",
        "## 一、系统回答的不是‘如何用更宏大的语言描述宇宙’，而是如何不再把语言当作宇宙本身",
        "",
        "人类语言把连续过程切分为名词，把多尺度因果压缩成句子，把不可同时呈现的关系排成线性序列。它是沟通工具，却不应被误认为现实的唯一底层格式。APEIRON95 因而取消‘自然语言文本是核心数据结构’这一默认假设。",
        "",
        "系统的规范核心由数值事件、时间差、关系、干预、预测分布、结构不变量、模型竞争和现实返回组成。中文、英文、宗教术语、数学符号乃至 DIKWP 标签都属于接口层；它们可以替换、扩展或撤回，而不改变已经登记的机器原生结构。",
        "",
        "这里所说的‘突破人类理解’具有严格边界：系统不声称获得了人类永远无法理解的神秘真理，而是能够证明，在一个明确的人类解码器和表达预算下，某些机器原生结构保留了更多可检验的预测差异。这个证明称为**超理解间隙证书**，其对象是特定投影的损失，不是对全人类认知能力的形而上判决。",
        "",
        "---",
        "",
        "## 二、五层架构",
        "",
        "### Ξ0：无标签事件织体",
        "",
        "基本记录为：",
        "",
        "```text",
        "e_t = <time-difference, observation-vector, action-code, environment-code, uncertainty>",
        "```",
        "",
        "人类维度名称、叙事说明和术语不进入核心摘要。动作和环境类别按首次出现顺序规范化，因此名称替换不会改变动力学结构。",
        "",
        "### Ξ1：跨尺度结构不变量",
        "",
        "系统在多个粗粒化尺度上计算状态频率多重集、转移计数多重集、度序列、循环秩、预测信息、动作信息增益、复现率和跨尺度分区持续性。它们优先描述‘关系如何保持’，而不是‘人类把它叫作什么’。",
        "",
        "### Ξ2：机器原生概念生成",
        "",
        "概念不以词语定义，而以操作等价定义：",
        "",
        "```math",
        "h_1 \\sim_c h_2",
        "\\Longleftrightarrow",
        "d(P(F\\mid do(A),h_1), P(F\\mid do(A),h_2)) \\le \\epsilon",
        "```",
        "",
        "即两个历史在未来预测、干预响应和结构特征上足够接近时，可形成一个不需要名称的概念。概念以 `ξ:<digest>` 标识；名字可以后来添加，但名字不是概念身份。",
        "",
        "### Ξ3：非同构世界模型竞争",
        "",
        "系统至少并行保留频率模型、预测状态模型、动作条件模型、二阶历史模型、机器概念模型、跨尺度模型、环境条件模型和复现过程模型。模型以留出预测损失与最小描述长度排序，但最佳模型仍不取得最终权威。",
        "",
        "### Ξ4：DIKWP 责任边界",
        "",
        "每个可能影响人类解释、价值、行动、宗教文明表述或权利的机器实体，都必须获得一个 DIKWP 信封：",
        "",
        "```math",
        "\\Phi: \\Xi \\rightarrow \\Delta(D,I,K,W,P) \\times Loss \\times Authority",
        "```",
        "",
        "投影损失进入 `I.TRANSLATION`、`W.CONSEQUENCE` 和 `P.VERIFICATION`；它不被藏在系统外。与此同时，`Φ(x)` 不替代 `x`。这同时满足‘全部纳入 DIKWP 责任空间’与‘不把非语言结构强行压扁为人类语义’。",
        "",
        "---",
        "",
        "## 三、‘终极’的可执行重定义",
        "",
        "APEIRON95 不把终极理解为不可推翻的最后理论，而把它定义为一个没有固定表征天花板、又不能逃离现实责任的开放极限：",
        "",
        "```math",
        "U^* = \\sup_{R,M,S}",
        "[PredictionGain + InterventionGain + Compression + Invariance",
        "- Complexity - Harm - HiddenBurden]",
        "```",
        "",
        "约束条件包括来源可追溯、多世界模型、结果回流、可撤回、具名授权、模型退役、后继世界自由以及自动外部行动权限为零。",
        "",
        "因此，一个系统越‘终极’，越必须公开自身的非终局条件；越能生成超出既有语言的结构，越必须提供可验证的证据、投影损失和停止条件。",
        "",
        "---",
        "",
        "## 四、本次可运行示例结果",
        "",
        f"本次示例接收 `{substrate['statistics']['event_count']}` 条数值事件、`{substrate['statistics']['dimension_count']}` 个观测维度、`{substrate['core']['action_cardinality']}` 类动作和 `{substrate['core']['environment_cardinality']}` 类环境。人类标签没有进入核心摘要。",
        "",
        f"多尺度分析覆盖 `{len(atlas['scales'])}` 个尺度，当前实用选择为 `{atlas['selected_bins']}` 个分箱；该选择只表示在当前评分函数下取得较好预测—复杂度平衡，不是宣称宇宙本体天然由该尺度构成。",
        "",
        f"系统从 `{concepts['state_count']}` 个离散状态中形成 `{concepts['concept_count']}` 个机器原生概念，概念压缩增益为 `{concepts['compression_gain_bits']:.4f}` bits，概念序列预测信息为 `{concepts['predictive_information_bits']:.4f}` bits。",
        "",
        f"世界模型集合包含 `{models['model_count']}` 个模型、`{len(models['non_isomorphic_model_families'])}` 个非同构家族。当前 MDL 排名第一的是 `{best['model_name']}`，留出平均对数损失为 `{best['average_test_log_loss_bits']:.4f}` bits，MDL 总长度为 `{best['mdl_total_bits']:.4f}` bits。",
        "",
        f"系统生成 `{causal['causal_hypothesis_count']}` 个干预关联候选和 `{causal['lagged_association_count']}` 个滞后关联。它们全部标记为候选或关联，没有签发因果证明。",
        "",
        f"DIKWP 边界登记 `{bridge['entity_count']}` 个受治理实体，空间外永久残差为 `{bridge['contract']['out_of_space_residual']}`；但每个投影明确说明不会替代非语言核心。",
        "",
        "### 多尺度结果",
        "",
        "| 分箱 | 状态数 | 预测信息(bits) | 动作信息增益(bits) | 复现率 | 选择分数 |",
        "|---:|---:|---:|---:|---:|---:|",
    ])
    for scale in sorted(atlas["scales"], key=lambda x: x["bins"]):
        inv = scale["invariants"]
        lines.append(f"| {scale['bins']} | {inv['state_count']} | {inv['predictive_information_bits']:.4f} | {inv['action_information_gain_bits']:.4f} | {_pct(inv['recurrence_rate'])} | {scale['selection_score']:.4f} |")
    lines.extend([
        "",
        "### 世界模型竞争",
        "",
        "| 排名 | 模型 | 非同构家族 | 测试损失(bits) | MDL(bits) | 相对零阶增益(bits) | 退役候选 |",
        "|---:|---|---|---:|---:|---:|---|",
    ])
    for model in models["models"]:
        lines.append(f"| {model['rank_by_mdl']} | `{model['model_name']}` | `{model['family']}` | {model['average_test_log_loss_bits']:.4f} | {model['mdl_total_bits']:.2f} | {model['mdl_gain_vs_zero_order_bits']:.2f} | {'是' if model['retirement_candidate'] else '否'} |")
    lines.extend([
        "",
        "### 机器原生概念样本",
        "",
        "| 不透明标识 | 支持事件 | 相对支持 | 成员状态 | 簇内距离 | 人类名称 |",
        "|---|---:|---:|---:|---:|---|",
    ])
    for concept in concepts["concepts"][:20]:
        lines.append(f"| `{concept['opaque_symbol']}` | {concept['support']} | {_pct(concept['relative_support'])} | {len(concept['member_state_ids'])} | {concept['within_cluster_distance']:.4f} | `null` |")
    lines.extend([
        "",
        "---",
        "",
        "## 五、超理解间隙证书",
        "",
        "证书只比较完整机器概念模型与一个受预算约束的‘保留前 k 个概念、其余合并’人类表格解码器。若合并后预测损失显著上升，则证明该投影遗漏了操作性差异。",
        "",
        "| 表达预算 | 合并概念数 | 完整损失 | 投影损失 | 额外损失 | 预测保真度 | 检测到间隙 |",
        "|---:|---:|---:|---:|---:|---:|---|",
    ])
    for cert in opacity["projection_certificates"]:
        lines.append(f"| {cert['budget']} | {cert['merged_concept_count']} | {cert['full_average_log_loss_bits']:.4f} | {cert['projected_average_log_loss_bits']:.4f} | {cert['additional_log_loss_bits']:.4f} | {_pct(cert['predictive_fidelity'])} | {'是' if cert['gap_detected'] else '否'} |")
    lines.extend([
        "",
        f"标签置换测试：`{'通过' if opacity['label_permutation_certificate']['passed'] else '未通过'}`。该测试只证明核心摘要不依赖提供的维度名称，不证明系统已经摆脱全部人类设计偏差。",
        "",
        "系统明确保留：`human_comprehension_impossibility_claim = false`，`ultimate_truth_certificate = null`。",
        "",
        "---",
        "",
        "## 六、世界宗教与文明如何进入这一系统",
        "",
        "上一代 COSMONOESIS95 的宗教文明 DIKWP 映射被作为人类语义边界层导入，而不是被当作宇宙本体核心。其原生术语、派别、经典来源和历史差异继续保留；每个概念都能进入 DIKWP 坐标，但不会据此宣布教义完全同一。",
        "",
        "APEIRON95 对宗教文明增加了新的双向路径：",
        "",
        "```text",
        "原生术语／仪式／历史记录",
        "          ↓  DIKWP归一与来源保存",
        "人类语义边界节点",
        "          ↕  有损但显式的桥接",
        "机器原生事件／关系／预测／不变量",
        "          ↓  现实结果返回",
        "更新解释、模型或实践判断",
        "```",
        "",
        "宗教概念不能自动充当物理实体，机器发现的结构也不能自动充当神学启示。二者可以共享关系、价值、目的或经验结构的坐标，但跨域等同必须另行提供机制与证据。",
        "",
        "---",
        "",
        "## 七、非语言宇宙接触协议",
        "",
        "系统生成一个完全离线的结构握手候选，使用重复、置换、逆变换、差分、组合和受控响应，而不预设中文、英文、数学术语或人类宗教概念。即便获得响应，也只能逐步提高‘具有可重复变换能力的能动系统’模型权重，不能直接证明意识、道德主体性或神圣地位。",
        "",
        "任何真实发射、公开、代表人类、干预未知对象或持续能量输出都必须经过具名授权、风险审阅和可停止条件。当前 `transmission_authorized = false`。",
        "",
        "---",
        "",
        "## 八、自我扩展而非秘密自我修改",
        "",
        f"本次生成 `{meta['proposal_count']}` 个表征变形提案。它们只能修改可回滚参数、增加尺度、提出区分性实验或设计新的解码器；不会自动执行代码、复制自身、隐藏驻留或获得外部权限。",
        "",
        "| 提案 | 原因 | 风险 | 状态 |",
        "|---|---|---|---|",
    ])
    for proposal in meta["proposals"]:
        lines.append(f"| `{proposal['kind']}` | {proposal['reason']} | {proposal['risk_level']} | `{proposal['status']}` |")
    lines.extend([
        "",
        "---",
        "",
        "## 九、核心边界",
        "",
        "本系统不声称：",
        "",
        "1. 已经发现宇宙的最终物理规律；",
        "2. 已经证明宇宙、星系、互联网或人工系统具有意识；",
        "3. 机器无法被人类理解的表示天然更真实；",
        "4. 压缩、预测或因果候选等于本体真理；",
        "5. 所有宗教历史上原本相同；",
        "6. DIKWP 投影可以无损替代原生传统或机器原生结构；",
        "7. 系统有权代表任何个人、宗教、文明或人类整体采取行动。",
        "",
        "系统实际交付的是：一个不受固定人类词汇表限制、能够生成不透明但可验证结构、能够记录理解损失、能够让现实推翻自身、并在所有人类影响边界重新进入 DIKWP 责任空间的开放基础设施。",
        "",
        "---",
        "",
        "## 十、研究基础与证据地位",
        "",
        "项目参考预测状态表示、最小描述长度、因果表征学习、世界模型以及机器发现算法等研究方向。它们说明若干组成机制在限定领域具有研究基础，但不共同证明本系统的宇宙论或‘终极性’。",
        "",
        "| 标识 | 文献 | 进入本系统的作用 |",
        "|---|---|---|",
    ])
    for source in bundle["research_basis"]["sources"]:
        lines.append(f"| `{source['id']}` | {source['title']} ({source['year']}) | {source['role']} |")
    lines.extend([
        "",
        "---",
        "",
        "## 十一、最终责任闭环",
        "",
        "```text",
        "无标签现实事件",
        "→ 多尺度结构发现",
        "→ 机器原生概念",
        "→ 非同构世界模型竞争",
        "→ 预测／干预候选",
        "→ 超理解投影损失证书",
        "→ DIKWP价值、目的、授权与负担审计",
        "→ 具名且可逆的现实接触",
        "→ 结果返回",
        "→ 模型修订／退役／概念重生",
        "→ 后继世界自由",
        "```",
        "",
        "这不是以语言宣布一个终极答案，而是交付一个允许宇宙持续纠正系统的结构。",
        "",
    ])
    return "\n".join(lines)


def render_dashboard(bundle: dict[str, Any]) -> str:
    atlas = bundle["multiscale_atlas"]
    concepts = bundle["machine_native_concepts"]
    models = bundle["world_model_ensemble"]
    opacity = bundle["transcomprehension_certificates"]
    causal = bundle["causal_hypotheses"]
    bridge = bundle["dikwp_boundary_bridge"]
    meta = bundle["metamorphosis_register"]
    model_rows = "".join(
        f"<tr><td>{m['rank_by_mdl']}</td><td><code>{html(m['model_name'])}</code></td><td>{html(m['family'])}</td><td>{m['average_test_log_loss_bits']:.4f}</td><td>{m['mdl_total_bits']:.2f}</td><td>{m['mdl_gain_vs_zero_order_bits']:.2f}</td></tr>"
        for m in models["models"]
    )
    scale_rows = "".join(
        f"<tr><td>{s['bins']}</td><td>{s['invariants']['state_count']}</td><td>{s['invariants']['predictive_information_bits']:.4f}</td><td>{s['invariants']['action_information_gain_bits']:.4f}</td><td>{s['selection_score']:.4f}</td></tr>"
        for s in sorted(atlas["scales"], key=lambda x: x["bins"])
    )
    concept_rows = "".join(
        f"<tr><td><code>{html(c['opaque_symbol'])}</code></td><td>{c['support']}</td><td>{_pct(c['relative_support'])}</td><td>{len(c['member_state_ids'])}</td><td>{c['within_cluster_distance']:.4f}</td><td>—</td></tr>"
        for c in concepts["concepts"][:24]
    )
    cert_rows = "".join(
        f"<tr><td>{c['budget']}</td><td>{c['merged_concept_count']}</td><td>{c['additional_log_loss_bits']:.4f}</td><td>{_pct(c['predictive_fidelity'])}</td><td>{'YES' if c['gap_detected'] else 'NO'}</td></tr>"
        for c in opacity["projection_certificates"]
    )
    proposal_rows = "".join(
        f"<tr><td><code>{html(p['kind'])}</code></td><td>{html(p['reason'])}</td><td>{html(p['risk_level'])}</td><td>{html(p['status'])}</td></tr>"
        for p in meta["proposals"]
    )
    max_score = max(abs(s["selection_score"]) for s in atlas["scales"]) or 1
    scale_bars = "".join(
        f"<div class='barrow'><span>{s['bins']} bins</span><div class='track'><div class='bar' style='width:{max(2, 100*max(0,s['selection_score'])/max_score):.1f}%'></div></div><b>{s['selection_score']:.3f}</b></div>"
        for s in sorted(atlas["scales"], key=lambda x: x["bins"])
    )
    payload = json.dumps({
        "compilation_id": bundle["compilation_id"],
        "core_digest": bundle["core_artifact"]["core_digest"],
        "model_count": models["model_count"],
        "concept_count": concepts["concept_count"],
    }, ensure_ascii=False)
    return f"""<!doctype html>
<html lang='zh-CN'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
<title>DIKWP-APEIRON 9.5 Dashboard</title>
<style>
:root{{--bg:#090d14;--panel:#111927;--panel2:#162235;--text:#edf4ff;--muted:#9fb0c8;--line:#283852;--accent:#6dd8ff;--accent2:#b5ff9d;--warn:#ffd58a}}
*{{box-sizing:border-box}}body{{margin:0;background:radial-gradient(circle at 20% 0,#17233b 0,#090d14 44%);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI","Noto Sans SC",sans-serif;line-height:1.55}}
main{{max-width:1320px;margin:auto;padding:34px}}header{{padding:38px;border:1px solid var(--line);border-radius:24px;background:linear-gradient(135deg,rgba(109,216,255,.12),rgba(181,255,157,.06));box-shadow:0 24px 80px rgba(0,0,0,.28)}}h1{{font-size:clamp(34px,5vw,72px);line-height:1;margin:0 0 14px;letter-spacing:-.04em}}h2{{margin:0 0 18px;font-size:25px}}h3{{margin:0 0 10px}}p{{color:var(--muted)}}code{{color:var(--accent2);word-break:break-all}}.eyebrow{{color:var(--accent);font-weight:700;letter-spacing:.13em;text-transform:uppercase}}.grid{{display:grid;grid-template-columns:repeat(12,1fr);gap:18px;margin-top:18px}}.card{{grid-column:span 4;background:linear-gradient(180deg,var(--panel2),var(--panel));border:1px solid var(--line);border-radius:18px;padding:22px;min-width:0}}.wide{{grid-column:span 12}}.half{{grid-column:span 6}}.metric{{font-size:36px;font-weight:800;letter-spacing:-.03em}}.label{{color:var(--muted);font-size:13px;text-transform:uppercase;letter-spacing:.08em}}table{{width:100%;border-collapse:collapse;font-size:13px}}th,td{{text-align:left;padding:10px 9px;border-bottom:1px solid var(--line);vertical-align:top}}th{{color:var(--accent);position:sticky;top:0;background:var(--panel)}}.scroll{{overflow:auto;max-height:510px}}.pill{{display:inline-block;padding:4px 9px;border:1px solid var(--line);border-radius:999px;color:var(--accent2);margin:2px;font-size:12px}}.barrow{{display:grid;grid-template-columns:72px 1fr 58px;gap:10px;align-items:center;margin:12px 0;color:var(--muted)}}.track{{height:12px;background:#0c111c;border:1px solid var(--line);border-radius:999px;overflow:hidden}}.bar{{height:100%;background:linear-gradient(90deg,var(--accent),var(--accent2));border-radius:999px}}.contract{{border-left:4px solid var(--accent2);padding:12px 16px;background:rgba(181,255,157,.05)}}.warning{{border-left-color:var(--warn);background:rgba(255,213,138,.05)}}footer{{color:var(--muted);padding:28px 4px}}@media(max-width:900px){{.card,.half{{grid-column:span 12}}main{{padding:16px}}}}
</style></head><body><main>
<header><div class='eyebrow'>Non-linguistic ontic core · DIKWP responsibility boundary</div><h1>DIKWP-APEIRON 9.5</h1><p>无标签事件、跨尺度不变量、机器原生概念、多世界模型、超理解投影损失与可逆现实接触。</p><p><code>{html(bundle['compilation_id'])}</code></p></header>
<section class='grid'>
<div class='card'><div class='label'>Events</div><div class='metric'>{bundle['ontic_event_lattice']['statistics']['event_count']}</div><p>数值事件；语言不是核心依赖。</p></div>
<div class='card'><div class='label'>Opaque concepts</div><div class='metric'>{concepts['concept_count']}</div><p>名称为 null，身份由预测和结构定义。</p></div>
<div class='card'><div class='label'>World models</div><div class='metric'>{models['model_count']}</div><p>{len(models['non_isomorphic_model_families'])} 个非同构模型家族。</p></div>
<div class='card'><div class='label'>Causal candidates</div><div class='metric'>{causal['causal_hypothesis_count']}</div><p>全部为候选；没有因果证书。</p></div>
<div class='card'><div class='label'>Governed entities</div><div class='metric'>{bridge['entity_count']}</div><p>全部获得 DIKWP 责任信封。</p></div>
<div class='card'><div class='label'>External authority</div><div class='metric'>0</div><p>Automatic external action authority 0</p></div>
<div class='card half'><h2>跨尺度结构</h2>{scale_bars}<div class='scroll'><table><thead><tr><th>尺度</th><th>状态</th><th>预测信息</th><th>动作增益</th><th>分数</th></tr></thead><tbody>{scale_rows}</tbody></table></div></div>
<div class='card half'><h2>核心合同</h2><div class='contract'><b>DIKWP 全域责任闭包</b><p>所有对人产生后果的实体都映射进入 DIKWP；投影损失也在空间内登记。</p></div><div class='contract warning'><b>不约简</b><p>DIKWP 投影不替代机器原生核心。`Φ(x) ≠ x`。</p></div><p><span class='pill'>labels optional</span><span class='pill'>reality return</span><span class='pill'>model retirement</span><span class='pill'>named authorization</span></p></div>
<div class='card wide'><h2>世界模型竞争</h2><div class='scroll'><table><thead><tr><th>排名</th><th>模型</th><th>家族</th><th>测试损失</th><th>MDL</th><th>相对增益</th></tr></thead><tbody>{model_rows}</tbody></table></div></div>
<div class='card wide'><h2>机器原生概念</h2><p>下列标识没有预设人类语义。可添加解释，但解释不是概念本体。</p><div class='scroll'><table><thead><tr><th>不透明标识</th><th>支持</th><th>占比</th><th>成员状态</th><th>簇内距离</th><th>名称</th></tr></thead><tbody>{concept_rows}</tbody></table></div></div>
<div class='card half'><h2>超理解间隙证书</h2><div class='scroll'><table><thead><tr><th>预算</th><th>合并</th><th>额外损失</th><th>保真</th><th>间隙</th></tr></thead><tbody>{cert_rows}</tbody></table></div><p>只证明指定解码器有损；不证明人类永远不能理解。</p></div>
<div class='card half'><h2>自我扩展提案</h2><div class='scroll'><table><thead><tr><th>类型</th><th>原因</th><th>风险</th><th>状态</th></tr></thead><tbody>{proposal_rows}</tbody></table></div></div>
<div class='card wide'><h2>非语言核心摘要</h2><p><code>{html(bundle['core_artifact']['core_digest'])}</code></p><p>APX95 二进制核心可由 `decode-core` 命令无损重放。维度名称和人类注释未进入摘要。</p></div>
</section>
<footer>DIKWP-APEIRON 9.5 · open-ended, reality-contacted, responsibility-closed · no claim of final cosmic truth.</footer>
<script>window.APEIRON95_SUMMARY={payload};</script>
</main></body></html>"""
