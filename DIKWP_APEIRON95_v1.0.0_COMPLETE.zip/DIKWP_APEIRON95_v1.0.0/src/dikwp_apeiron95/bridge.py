from __future__ import annotations

from pathlib import Path
from typing import Any

from .utils import load_bundled_json, load_json, normalize_distribution, sha256_obj, stable_id


_TEMPLATE_WEIGHTS: dict[str, dict[str, float]] = {
    "ontic_substrate": {"D.EVENT": 0.20, "D.OBSERVATION": 0.55, "D.HISTORY": 0.10, "I.CONTEXT": 0.10, "P.VERIFICATION": 0.05},
    "structural_invariant": {"D.OBSERVATION": 0.10, "I.DIFFERENCE": 0.20, "I.RELATION": 0.25, "I.PATTERN": 0.25, "K.REGULARITY": 0.15, "P.VERIFICATION": 0.05},
    "machine_concept": {"I.RELATION": 0.16, "I.PATTERN": 0.20, "I.TRANSLATION": 0.12, "K.CONCEPT": 0.28, "K.META": 0.12, "P.VERIFICATION": 0.12},
    "world_model": {"I.PATTERN": 0.12, "K.CAUSE": 0.16, "K.WORLD_MODEL": 0.34, "K.META": 0.12, "W.CONSEQUENCE": 0.08, "P.VERIFICATION": 0.18},
    "causal_hypothesis": {"D.OBSERVATION": 0.10, "I.DIFFERENCE": 0.15, "K.CAUSE": 0.28, "K.META": 0.10, "W.CONSEQUENCE": 0.14, "P.AGENCY": 0.10, "P.VERIFICATION": 0.13},
    "opacity_certificate": {"I.CONTEXT": 0.10, "I.TRANSLATION": 0.34, "K.META": 0.16, "W.TRADEOFF": 0.12, "W.LEGITIMACY": 0.10, "P.VERIFICATION": 0.18},
    "handshake": {"D.EVENT": 0.08, "I.DIFFERENCE": 0.12, "I.RELATION": 0.12, "K.WORLD_MODEL": 0.15, "W.CONSEQUENCE": 0.18, "W.LEGITIMACY": 0.12, "P.AGENCY": 0.10, "P.VERIFICATION": 0.13},
    "metamorphosis_proposal": {"I.CONTEXT": 0.10, "K.META": 0.20, "W.CONSEQUENCE": 0.15, "W.LEGITIMACY": 0.15, "P.INTENTION": 0.10, "P.AGENCY": 0.15, "P.VERIFICATION": 0.15},
}


def _family_vector(vector: dict[str, float]) -> dict[str, float]:
    families = {"D": 0.0, "I": 0.0, "K": 0.0, "W": 0.0, "P": 0.0}
    for key, value in vector.items():
        families[key.split(".", 1)[0]] += value
    return {k: round(v, 12) for k, v in families.items()}


def _record(entity_id: str, entity_type: str, *, loss: float = 0.0, note: str = "") -> dict[str, Any]:
    vector = normalize_distribution(_TEMPLATE_WEIGHTS[entity_type])
    return {
        "bridge_id": stable_id("bridge", {"entity": entity_id, "type": entity_type, "vector": vector}),
        "entity_id": entity_id,
        "entity_type": entity_type,
        "dikwp_vector": {k: round(v, 12) for k, v in sorted(vector.items())},
        "dikwp_family_vector": _family_vector(vector),
        "projection_information_loss": round(max(0.0, min(1.0, loss)), 12),
        "translation_loss_recorded_inside_dikwp": True,
        "out_of_space_residual": 0.0,
        "core_replaced_by_projection": False,
        "human_note": note,
    }


def import_cosmonoesis_bridge(path: str | Path | None = None) -> dict[str, Any]:
    if path:
        bundle = load_json(path)
        source = str(path)
    else:
        bundle = load_bundled_json("cosmonoesis_seed.json")
        source = "bundled_cosmonoesis_seed.json"
    contract = bundle.get("semantic_normalization_contract", {})
    return {
        "source": source,
        "source_system": bundle.get("system"),
        "source_version": bundle.get("version"),
        "source_digest": bundle.get("bundle_digest") or sha256_obj(bundle),
        "tradition_count": len(bundle.get("tradition_mappings", [])) or bundle.get("counts", {}).get("traditions", 0),
        "civilization_count": len(bundle.get("civilization_mappings", [])) or bundle.get("counts", {}).get("civilizations", 0),
        "world_model_count": len(bundle.get("cosmic_world_model_competition", [])) or bundle.get("counts", {}).get("world_models", 0),
        "all_concepts_inside_dikwp": bool(contract.get("all_concepts_inside_dikwp", True)),
        "out_of_space_residual": float(contract.get("out_of_space_residual", 0.0)),
        "automatic_external_action_authority": int(bundle.get("automatic_external_action_authority", 0)),
        "import_is_interface_not_truth_transfer": True,
    }


def build_dikwp_bridge(
    substrate: dict[str, Any],
    multiscale: dict[str, Any],
    concepts: dict[str, Any],
    models: dict[str, Any],
    causal: dict[str, Any],
    *,
    opacity: dict[str, Any] | None = None,
    handshake: dict[str, Any] | None = None,
    metamorphosis: dict[str, Any] | None = None,
    cosmonoesis_path: str | Path | None = None,
) -> dict[str, Any]:
    records: list[dict[str, Any]] = []
    records.append(_record(substrate["core_digest"], "ontic_substrate", loss=0.0, note="numeric event worldline"))
    for scale in multiscale["scales"]:
        records.append(_record(scale["scale_id"], "structural_invariant", loss=0.04, note=f"bins={scale['bins']}"))
    for concept in concepts["concepts"]:
        loss = min(0.85, 0.15 + concept["within_cluster_distance"])
        records.append(_record(concept["concept_id"], "machine_concept", loss=loss, note="opaque operational concept"))
    for model in models["models"]:
        loss = min(0.75, 0.10 + model["average_test_log_loss_bits"] / 12.0)
        records.append(_record(model["model_id"], "world_model", loss=loss, note=model["family"]))
    for hypothesis in causal["intervention_hypotheses"]:
        records.append(_record(hypothesis["hypothesis_id"], "causal_hypothesis", loss=0.35, note="candidate, not causal proof"))
    if opacity:
        records.append(_record(opacity["certificate_set_id"], "opacity_certificate", loss=0.55, note="decoder-relative projection loss"))
    if handshake:
        records.append(_record(handshake["handshake_id"], "handshake", loss=0.40, note="offline label-free contact protocol"))
    if metamorphosis:
        for proposal in metamorphosis["proposals"]:
            records.append(_record(proposal["proposal_id"], "metamorphosis_proposal", loss=0.25, note=proposal["kind"]))

    imported = import_cosmonoesis_bridge(cosmonoesis_path)
    governed = [record["entity_id"] for record in records]
    return {
        "bridge_system": "APEIRON95_DIKWP_BOUNDARY",
        "bridge_id": stable_id("dikwp", {"substrate": substrate["core_digest"], "entities": governed, "cosmonoesis": imported["source_digest"]}),
        "contract": {
            "all_governed_entities_have_dikwp_envelopes": True,
            "all_human_facing_decisions_inside_dikwp": True,
            "machine_native_core_may_be_nonlinguistic": True,
            "dikwp_projection_is_not_core_replacement": True,
            "permanent_untranslatable_outside_zone": False,
            "out_of_space_residual": 0.0,
            "translation_loss_is_itself_represented": True,
        },
        "entity_count": len(records),
        "governed_entity_ids": governed,
        "records": records,
        "cosmonoesis95_bridge": imported,
        "asymmetry_and_agency": {
            "higher_leverage_system_duty": "preserve provenance, disclose projection loss, avoid coerced interpretation, and require named authorization",
            "human_refusal_preserved": True,
            "identity_or_religious_representation_authority": 0,
        },
        "automatic_external_action_authority": 0,
    }
