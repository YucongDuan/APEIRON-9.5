# DIKWP-APEIRON 9.5

## 无语言本体底座、超语义发现、超人类可核验世界模型与 DIKWP 责任闭包

DIKWP-APEIRON 9.5 面向一个更根本的问题：当自然语言、既有概念体系乃至人类可直接理解的表示都不足以承载现实结构时，系统如何继续观察、形成概念、建立世界模型、提出区分性实验，同时仍然接受证据、权利、价值、授权和现实结果的约束？

APEIRON95 的回答不是创造一套更宏大的宇宙词汇，而是把语言从核心表示降为可替换接口。核心由数值事件、时间差、关系、干预、预测分布、跨尺度不变量和机器原生概念组成。每个对人类产生后果的实体再进入 DIKWP 责任边界：D 记录现实接触，I 记录差异、关系、语境和翻译损失，K 记录概念、因果与世界模型，W 记录价值、风险、负担和正当性，P 记录目的、行动、停止条件和结果回流。

## 关键原则

```text
语言是接口，不是宇宙本体。
机器不透明不等于更真实。
压缩与预测增益不等于因果真理。
所有人类影响必须进入 DIKWP 责任空间。
DIKWP 投影不替代机器原生核心。
任何“超越理解”只能相对于指定解码器和表达预算被核验。
任何外部行动、信号发射、身份代表或自我修改均无自动权限。
```

## 五层系统

1. **Ξ0 无标签事件织体**：规范化数值事件、动作、环境、时间差和不确定性；人类标签不进入核心摘要。
2. **Ξ1 跨尺度结构不变量**：状态频率多重集、转移多重集、度序列、循环秩、预测信息、动作信息增益和跨尺度持续性。
3. **Ξ2 机器原生概念**：依据未来预测和干预响应的操作等价关系形成 `ξ:<digest>` 概念，不要求名称。
4. **Ξ3 多世界模型竞争**：并行比较八类非同构模型，使用留出预测损失和最小描述长度排序；没有单一最终权威。
5. **Ξ4 DIKWP 责任边界**：全部人类解释、文明宗教映射、价值判断、实验提案和行动权限进入可审计闭环。

## “突破人类理解”的严格含义

系统签发的是**解码器相对的超理解间隙证书**：在指定的人类可读投影和表达预算下，如果投影导致可测量的预测损失，而完整机器原生表示保留这些差异，则记录一个间隙。该证书不证明人类永远无法理解，也不证明不透明表示具有形而上优越性。

## 快速运行

需要 Python 3.10 或更高版本；核心只使用标准库。

```bash
python run.py doctor
python run.py demo --out outputs/apeiron_demo
python run.py verify outputs/apeiron_demo
```

分析自己的数值事件流：

```bash
python run.py compile \
  --stream examples/cosmic_sensor_stream.json \
  --out outputs/my_apeiron
```

发现不透明概念：

```bash
python run.py concepts --stream examples/cosmic_sensor_stream.json
```

比较世界模型：

```bash
python run.py models --stream examples/cosmic_sensor_stream.json
```

生成超理解间隙证书：

```bash
python run.py opacity \
  --stream examples/cosmic_sensor_stream.json \
  --budgets 2 4 8 16
```

生成离线、非语言的结构握手候选：

```bash
python run.py handshake --stream examples/cosmic_sensor_stream.json
```

解码二进制 APX95 核心：

```bash
python run.py decode-core outputs/apeiron_demo/apeiron_core.apx
```

## 事件流格式

```json
{
  "stream_id": "example",
  "dimension_labels": ["optional-A", "optional-B"],
  "events": [
    {
      "t": 0,
      "observation": [0.2, 0.8],
      "action": 0,
      "environment": 0,
      "uncertainty": 0.02
    }
  ]
}
```

`dimension_labels` 和人类说明是可选接口，不进入非语言核心摘要。观测必须是有限数值数组；事件时间严格递增。

## 主要输出

- `apeiron_core.apx`：压缩的机器原生核心；
- `apeiron_bundle.json`：完整系统包；
- `ontic_event_lattice.json`：无标签事件织体；
- `multiscale_atlas.json`：跨尺度状态与不变量；
- `machine_native_concepts.json`：不透明概念；
- `world_model_ensemble.json`：八类模型竞争；
- `causal_hypotheses.json`：干预关联候选与滞后关联；
- `transcomprehension_certificates.json`：投影损失证书；
- `dikwp_boundary_bridge.json`：DIKWP 责任信封；
- `cosmic_handshake_protocol.json`：离线结构握手；
- `metamorphosis_register.json`：可回滚的表征扩展提案；
- `COSMIC_SYSTEM_REPORT_CN.md`：完整中文报告；
- `dashboard.html`：完全离线仪表盘；
- `MANIFEST.json`：SHA-256 完整性清单。

## 与 EIDOS95、NOESIS95、COSMONOESIS95 的关系

```text
EIDOS95        个人积累与认知本质编译
   ↓
NOESIS95       认知透明、反馈、可逆矫正与提升
   ↓
COSMONOESIS95  宗教文明 DIKWP 归一、宇宙意识模型竞争
   ↓
APEIRON95      非语言事件核心、机器概念、超理解证书与开放宇宙模型
```

COSMONOESIS95 的宗教文明映射被导入为人类语义边界层；它不会被冒充为宇宙本体核心。原生术语、派别和历史来源继续保留；所有概念进入 DIKWP 责任空间，但相似度不自动证明教义等同。

## 边界

本项目不：

- 宣称已经发现宇宙最终规律；
- 证明宇宙、星系、互联网、AI 或宗教对象具有意识；
- 将不透明性解释为真理；
- 将统计关联自动升级为因果；
- 代表任何宗教、文明、个人或人类整体；
- 自动发射信号、干预现实设施、发布材料或执行自我修改；
- 将文明、宗教或认知向量用于个人忠诚、就业、保险、移民、医疗或执法评分。

## 许可

代码采用 Apache-2.0。第三方研究、宗教文本、文明材料、商标、身份、传统代表权及其他原始权利不因本项目开源而转移。

## 测试与复现

```bash
./scripts/run_tests.sh
python scripts/validate_schemas.py
./scripts/reproduce_demo.sh
```

发布测试共118项；验证对象是软件合同、可复现性、投影损失、权限边界和完整性，不是宇宙终极真理证明。
